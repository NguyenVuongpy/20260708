import os
import sys
from datetime import datetime
import pandas as pd
import numpy as np
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect, QComboBox, QDialog, QTableWidget, QTableWidgetItem,
    QScrollArea, QGridLayout
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize, QTimer
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
from openpyxl import Workbook
from openpyxl.styles import Alignment, PatternFill, Border, Side, Font, Color
from openpyxl.utils import get_column_letter
from openpyxl import load_workbook

try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None
from PyQt6 import QtCore, QtGui, QtWidgets
import rc.icons
from log_functions import script_dir

# Import detectors and CCD model helpers
from detector.hotpixel_detector import HotpixelChecker
from detector.bubble_detector import BubbleCheckerThread
from detector.lshape_detector import LShapeCheckerThread
from detector.ccd_detector import CCDChecker
from detector.hiaa_detector import HiaaCheckerThread
from detector.dust_detector import DustCheckerThread
from detector.topedge_detector import Top_EdgeCheckerThread
from detector.blackline_detector import BlackLineCheckerThread


class CombinedDetectorController(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    update_detector_status = pyqtSignal(str, str)  # Signal: detector_name, status
    finished = pyqtSignal(dict)

    def __init__(self, root_folder):
        super().__init__()
        self.root_folder = root_folder

        self.results = {
            'hotpixel': [],
            'ccd': [],
            'bubble': [],
            'lshape': [],
            'hiaa': [],
            'dust': [],
            'topedge': [],
            'blackline': []
        }

        self.detectors = [
            {"name": "HotPixel", "key": "hotpixel", "thread": None, "status": "pending"},
            {"name": "CCD", "key": "ccd", "thread": None, "status": "pending"},
            {"name": "Bubble", "key": "bubble", "thread": None, "status": "pending"},
            {"name": "LShape", "key": "lshape", "thread": None, "status": "pending"},
            {"name": "Dust", "key": "dust", "thread": None, "status": "pending"},
            {"name": "Hiaa", "key": "hiaa", "thread": None, "status": "pending"},
            {"name": "TopEdge", "key": "topedge", "thread": None, "status": "pending"},
            {"name": "BlackLine", "key": "blackline", "thread": None, "status": "pending"}
        ]

        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        self.timestamp = timestamp
        self.output_root_dir = os.path.join(script_dir, "PUC_Crop_Image_Result")
        os.makedirs(self.output_root_dir, exist_ok=True)
        self.run_output_folder = os.path.join(self.output_root_dir, f"{timestamp}_Check_Result")
        os.makedirs(self.run_output_folder, exist_ok=True)

        self.combined_path = os.path.join(self.run_output_folder, "Analysis_Report.xlsx")
        self.summary_csv_path = os.path.join(self.run_output_folder, "Summary_log.csv")
        
        self._summary_initialized = False
        
        # Log file sẽ nằm trong thư mục _Check_Result
        self.log_file_path = os.path.join(self.run_output_folder, f"Run_Log_{timestamp}.txt")
        try:
            with open(self.log_file_path, "w", encoding="utf-8") as f:
                f.write("")
        except Exception:
            self.log_file_path = None

    def _write_log(self, message: str):
        """
        Send logs to the UI and simultaneously write them to a text file.
        Log file is saved in the _Check_Result folder.
        """
        timestamp_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        full_message = f"[{timestamp_str}] {message}"
        self.update_log.emit(full_message)
        if self.log_file_path:
            try:
                with open(self.log_file_path, "a", encoding="utf-8") as f:
                    f.write(full_message + "\n")
            except Exception:
                pass

    def _forward_log(self, prefix):
        def _inner(message):
            self._write_log(f"[{prefix}] {message}")
        return _inner

    def run(self):
        try:
            # Ensure combined workbook exists
            self._ensure_combined_workbook()
            
            # Update all detectors to "pending" first
            for det in self.detectors:
                det["status"] = "pending"
                self.update_detector_status.emit(det["name"], "pending")
            
            self._write_log(f"Starting all detectors in root folder: {self.root_folder}")
            
            # HotPixel
            current_det = self.detectors[0]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            hot_thread = HotpixelChecker(self.root_folder, summary_output_folder=self.run_output_folder)
            hot_thread.update_log.connect(self._forward_log(current_det['name']))
            hot_thread.update_progress.connect(lambda p: self.update_progress.emit(int(p/8)))
            result_container = []
            hot_thread.finished.connect(lambda folders: result_container.extend(folders))
            hot_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hotpixel'] = list(set(result_container))
            self._append_summary_row(current_det['name'], self.results['hotpixel'])

            # CCD
            current_det = self.detectors[1]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            ccd_thread = CCDChecker(self.root_folder, summary_output_folder=self.run_output_folder)
            ccd_thread.update_log.connect(self._forward_log(current_det['name']))
            ccd_thread.update_progress.connect(lambda p: self.update_progress.emit(int(100/8 + p/8)))
            ccd_result_container = []
            ccd_thread.finished.connect(lambda folders: ccd_result_container.extend(folders))
            ccd_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['ccd'] = list(set(ccd_result_container))
            self._append_summary_row(current_det['name'], self.results['ccd'])

            # Bubble
            current_det = self.detectors[2]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            bubble_thread = BubbleCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            bubble_thread.update_log.connect(self._forward_log(current_det['name']))
            bubble_thread.update_progress.connect(lambda p: self.update_progress.emit(int(200/8 + p/8)))
            bubble_result_container = []
            bubble_thread.finished.connect(lambda folders: bubble_result_container.extend(folders))
            bubble_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['bubble'] = list(set(bubble_result_container))
            self._append_summary_row(current_det['name'], self.results['bubble'])

            # LShape
            current_det = self.detectors[3]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            lshape_thread = LShapeCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            lshape_thread.update_log.connect(self._forward_log(current_det['name']))
            lshape_thread.update_progress.connect(lambda p: self.update_progress.emit(int(300/8 + p/8)))
            lshape_result_container = []
            lshape_thread.finished.connect(lambda folders: lshape_result_container.extend(folders))
            lshape_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['lshape'] = list(set(lshape_result_container))
            self._append_summary_row(current_det['name'], self.results['lshape'])

            # Dust
            current_det = self.detectors[4]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            dust_thread = DustCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            dust_thread.update_log.connect(self._forward_log(current_det['name']))
            dust_thread.update_progress.connect(lambda p: self.update_progress.emit(int(400/8 + p/8)))
            dust_result_container = []
            dust_thread.finished.connect(lambda folders: dust_result_container.extend(folders))
            dust_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['dust'] = list(set(dust_result_container))
            self._append_summary_row(current_det['name'], self.results['dust'])

            # Hiaa
            current_det = self.detectors[5]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            hiaa_thread = HiaaCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            hiaa_thread.update_log.connect(self._forward_log(current_det['name']))
            hiaa_thread.update_progress.connect(lambda p: self.update_progress.emit(int(500/8 + p/8)))
            hiaa_result_container = []
            hiaa_thread.finished.connect(lambda folders: hiaa_result_container.extend(folders))
            hiaa_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['hiaa'] = list(set(hiaa_result_container))
            self._append_summary_row(current_det['name'], self.results['hiaa'])

            # TopEdge
            current_det = self.detectors[6]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self.update_log.emit(f"Starting {current_det['name']} Detector...")
            
            topedge_thread = Top_EdgeCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            topedge_thread.update_log.connect(self._forward_log(current_det['name']))
            topedge_thread.update_progress.connect(lambda p: self.update_progress.emit(int(600/8 + p/8)))
            topedge_result_container = []
            topedge_thread.finished.connect(lambda folders: topedge_result_container.extend(folders))
            topedge_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['topedge'] = list(set(topedge_result_container))
            self._append_summary_row(current_det['name'], self.results['topedge'])

            # BlackLine
            current_det = self.detectors[7]
            current_det["status"] = "Checking"
            self.update_detector_status.emit(current_det['name'], "Checking")
            self._write_log(f"Starting {current_det['name']} Detector...")
            
            blackline_thread = BlackLineCheckerThread(self.root_folder, summary_output_folder=self.run_output_folder)
            blackline_thread.update_log.connect(self._forward_log(current_det['name']))
            blackline_thread.update_progress.connect(lambda p: self.update_progress.emit(int(700/8 + p/8)))
            blackline_result_container = []
            blackline_thread.finished.connect(lambda folders: blackline_result_container.extend(folders))
            blackline_thread.run()
            
            current_det["status"] = "completed"
            self.update_detector_status.emit(current_det['name'], "completed")
            self.results['blackline'] = list(set(blackline_result_container))
            self._append_summary_row(current_det['name'], self.results['blackline'])

            # Apply a simple heatmap to the "Total Camera" column.
            self._apply_heatmap_to_total_camera()

            # Create CSV file.
            self._create_combined_csv()

            self.update_progress.emit(100)
            self._write_log("✅ All checks completed!")
            self.finished.emit(self.results)
        except Exception as e:
            self._write_log(f"Error: {type(e).__name__} - {str(e)}")
            self.finished.emit(self.results)

    def _ensure_combined_workbook(self):
        if self._summary_initialized and os.path.exists(self.combined_path):
            return
        from openpyxl import load_workbook as _lw
        if os.path.exists(self.combined_path):
            wb = _lw(self.combined_path)
            if "Summary" in wb.sheetnames:
                ws = wb["Summary"]
                ws.delete_rows(1, ws.max_row)
            else:
                ws = wb.create_sheet("Summary")
        else:
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"
        
        headers = ["Detector", "Total Camera", "Camera List"]
        header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
        header_font = Font(size=12, bold=True, color="333333")
        thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.alignment = Alignment(horizontal='center', vertical='center')
            c.fill = header_fill
            c.font = header_font
            c.border = thin_border
            ws.column_dimensions[get_column_letter(col_idx)].width = 30 if col_idx != 3 else 60
        wb.save(self.combined_path)
        self._summary_initialized = True

    def _get_checked_cameras_count(self):
        """Get the actual number of cameras that have been checked."""
        if not os.path.exists(self.root_folder):
            return 0
        
        # Get all folders in root_folder
        all_camera_folders = [f for f in os.listdir(self.root_folder) 
                             if os.path.isdir(os.path.join(self.root_folder, f))]
        
        # Remove the analysis results folders.
        excluded_folders = ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", 
                           "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                           "Bubble_Analysis_Results", "LShape_Analysis_Results",
                           "Top_Edge_Analysis_Results", "BlackLine_Analysis_Results"]
        
        camera_folders = [f for f in all_camera_folders if f not in excluded_folders]
        
        # Count the number of cameras that have at least one image file to check.
        checked_cameras = 0
        for camera in camera_folders:
            camera_path = os.path.join(self.root_folder, camera)
            # Check if there are any image files in the folder.
            image_extensions = ['.tif', '.tiff', '.png', '.jpg', '.jpeg', '.bmp']
            has_images = any(f.lower().endswith(tuple(image_extensions)) 
                           for f in os.listdir(camera_path) if os.path.isfile(os.path.join(camera_path, f)))
            if has_images:
                checked_cameras += 1
        
        return checked_cameras, len(camera_folders)

    def _append_summary_row(self, name, folders):
        try:
            from openpyxl import load_workbook as _lw
            wb = _lw(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))
            
            folders_sorted = sorted(set(folders)) if folders else []
            error_count = len(folders_sorted)
            
            # Get the number of cameras checked and the total number of cameras.
            checked_cameras, total_cameras = self._get_checked_cameras_count()
            
            # Display: "Number of faulty cameras / Number of cameras checked (total number of cameras)"
            if checked_cameras > 0:
                if total_cameras > checked_cameras:
                    camera_count_text = f"{error_count} / {checked_cameras} ({total_cameras})"
                else:
                    camera_count_text = f"{error_count} / {checked_cameras}"
            else:
                camera_count_text = f"{error_count} / 0 ({total_cameras})"
            
            # Create a list of cameras with clear formatting.
            camera_list_text = "\n".join(folders_sorted)
            
            ws.append([name, camera_count_text, camera_list_text])
            row = ws.max_row
            
            # Apply formatting to all cells in the row.
            for col in range(1, 4):
                cell = ws.cell(row=row, column=col)
                cell.alignment = Alignment(horizontal='left', vertical='top', wrapText=True)
                cell.border = thin_border
            
            # Specifically, center the "Total Camera" column.
            total_camera_cell = ws.cell(row=row, column=2)
            total_camera_cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)
            
            wb.save(self.combined_path)
            self.update_log.emit(f"Summary updated: {name} -> {camera_count_text}")
        except Exception as e:
            self.update_log.emit(f"Warning: could not update Summary for {name}: {e}")

    def _apply_heatmap_to_total_camera(self):
        """Apply a simple heatmap to the Total Camera column."""
        try:
            from openpyxl import load_workbook
            from openpyxl.styles import PatternFill
            
            wb = load_workbook(self.combined_path)
            ws = wb["Summary"] if "Summary" in wb.sheetnames else wb.active
            
            # Fixed colors for a simple heatmap
            colors = {
                'low': "C6EFCE",    # Light green (0% error rate)
                'medium': "FFEB9C", # Pale yellow (<=50% error rate)
                'high': "FFC7CE"    # Light red (>50% error rate)
            }
            
            for row in range(2, ws.max_row + 1):
                cell = ws.cell(row=row, column=2)
                value = str(cell.value or "")
                
                try:
                    if '/' in value:
                        # Parse: "error_count / checked_cameras (total_cameras)"
                        parts = value.split('/')
                        error_count = int(parts[0].strip())
                        
                        # Get the checked_cameras number
                        checked_part = parts[1].strip().split('(')[0].strip()
                        checked_cameras = int(checked_part) if checked_part else 1
                        
                        # Calculate the error rate.
                        if checked_cameras > 0:
                            error_ratio = error_count / checked_cameras
                        else:
                            error_ratio = 0
                        
                        # Choose colors based on proportions.
                        if error_ratio == 0:
                            color = colors['low']
                        elif error_ratio <= 0.5:
                            color = colors['medium']
                        else:
                            color = colors['high']
                        
                        # Apply color
                        cell.fill = PatternFill(start_color=color, end_color=color, fill_type="solid")
                        
                except Exception:
                    continue  # Skip if it cannot be parsed
            
            wb.save(self.combined_path)
            self.update_log.emit("✅ Heatmap applied to Total Camera column")
            
        except Exception as e:
            self.update_log.emit(f"Warning: could not apply heatmap: {e}")

    def _convert_numpy_types(self, value):
        """Convert numpy types to Python native types"""
        if value is None:
            return value
        
        # Check if value is a numpy scalar
        if isinstance(value, np.generic):
            # Convert numpy scalar to Python native type
            return value.item()
        
        # Check if value is a numpy array
        if isinstance(value, np.ndarray):
            # Convert numpy array to list
            return value.tolist()
        
        # For lists/tuples containing numpy types
        if isinstance(value, (list, tuple)):
            return [self._convert_numpy_types(item) for item in value]
        
        # For strings that might contain numpy representations
        if isinstance(value, str):
            # Clean up np.int64 strings
            import re
            # Pattern to match np.int64(123) or np.float64(123.45)
            pattern = r'np\.(?:int|float)\d+\(([^)]+)\)'
            if re.search(pattern, value):
                # Replace np.int64(123) with 123
                value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _format_special_values(self, value):
        """Format special values like tuples, lists, numpy arrays for CSV output"""
        if value is None:
            return ''
        
        # Convert numpy types first
        value = self._convert_numpy_types(value)
        
        # Handle tuples
        if isinstance(value, tuple):
            # Format each element as string
            return f"({', '.join(str(item) for item in value)})"
        
        # Handle lists
        if isinstance(value, list):
            # Format each element as string
            return f"[{', '.join(str(item) for item in value)}]"
        
        # Handle strings that might still contain numpy representations
        if isinstance(value, str):
            # Further clean up if needed
            import re
            # Clean up any remaining numpy representations
            value = re.sub(r'np\.(?:int|float)\d+\(([^)]+)\)', r'\1', value)
        
        return value

    def _convert_bbox_to_coordinate_pairs(self, defect_positions_str):
        """
        Convert bounding box format (x, y, w, h) to (x1, y1)-(x2, y2) format.
        Input: "(594,581,269,41); (594,582,269,41)"  # (x, y, width, height)
        Output: "(594,581)-(863,622); (594,582)-(863,623)"  # (x1, y1)-(x2, y2)
        """
        import re
        if not defect_positions_str:
            return ""
        
        # Clean the string and split by semicolon
        defect_positions_str = str(defect_positions_str).strip()
        if defect_positions_str == "" or defect_positions_str.lower() == "nan":
            return ""
        
        # Parse all bounding boxes
        pattern = r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)"
        matches = re.findall(pattern, defect_positions_str)
        
        formatted_boxes = []
        for match in matches:
            try:
                x, y, w, h = map(int, match)
                x2 = x + w
                y2 = y + h
                formatted_boxes.append(f"({x},{y})-({x2},{y2})")
            except ValueError:
                # If parsing fails, keep original
                formatted_boxes.append(f"({','.join(match)})")
        
        return "; ".join(formatted_boxes) if formatted_boxes else defect_positions_str

    def _clean_dataframe_columns(self, df):
        """Clean all columns in DataFrame to remove numpy types"""
        if df.empty:
            return df
        
        # Apply conversion to all cells
        for col in df.columns:
            df[col] = df[col].apply(self._convert_numpy_types)
        
        return df

    def _safe_str(self, v):
        try:
            if v is None:
                return ""
            if isinstance(v, float) and pd.isna(v):
                return ""
            return str(v)
        except Exception:
            return ""

    def _normalize_result(self, value):
        """Normalize Result column values to 'NG' (error) or 'OK' (no error) or 'No Check'"""
        if value is None:
            return "OK"
        
        value_str = str(value).strip()
        value_lower = value_str.lower()
        
        # If already normalized, return as is
        if value_lower == "ng":
            return "NG"
        if value_lower == "ok":
            return "OK"
        if value_lower == "no check":
            return "No Check"
        
        # Check for error indicators
        error_indicators = [
            "hotpixel found", "ccd detected", "bubble found", 
            "lshape defect found", "dust found", "hiaa found", 
            "top_edge found", "topedge found", "blackline found",
            "yes", "true", 
            "detected", "found", "error", "defect"
        ]
        
        # Check if value indicates an error
        for indicator in error_indicators:
            if indicator in value_lower:
                return "NG"
        
        # Default to OK if value is "No", "False", or empty
        if value_lower in ["no", "false", ""]:
            return "OK"
        
        # If we can't determine, default to OK
        return "OK"

    def _extract_pid_sn(self, file_name: str) -> str:
        """Extract PID from file name by taking characters before first '_'."""
        s = self._safe_str(file_name)
        if not s:
            return ""
        return s.split("_", 1)[0]

    def _parse_positions_from_row(self, detector_name: str, row) -> list[tuple[float, float]]:
        """
        Extract positions used to compare 'same location' across files.
        """
        import re

        positions: list[tuple[float, float]] = []

        if detector_name == "Hotpixel":
            s = self._safe_str(row.get("Hotpixel Position", ""))
            m = re.search(r"\(\s*(\d+)\s*,\s*(\d+)\s*\)", s)
            if m:
                positions.append((float(m.group(1)), float(m.group(2))))
            return positions

        if detector_name in {"Bubble", "Dust", "LShape"}:
            s = self._safe_str(row.get("Defect Positions", ""))
            for m in re.finditer(r"\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", s):
                x, y, w, h = map(float, m.groups())
                # Calculate center point
                positions.append((x + w / 2.0, y + h / 2.0))
            return positions

        if detector_name == "CCD":
            s = self._safe_str(row.get("Error Positions", ""))
            for m in re.finditer(
                r"\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*-\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)",
                s,
            ):
                x1, y1, x2, y2 = map(float, m.groups())
                positions.append(((x1 + x2) / 2.0, (y1 + y2) / 2.0))
            return positions

        return positions

    def _filter_df_require_common_positions(self, detector_name: str, df: pd.DataFrame) -> pd.DataFrame:
        """
        Return ALL data without filtering by common positions.
        """
        # Simply return the DataFrame as-is (no filtering)
        return df.copy()

    def _create_combined_csv(self):
        """Create combined CSV file with all defect data grouped by image file"""
        try:
            self.update_log.emit("Creating combined CSV file...")
            
            # Define CSV files to read (try both subfolder and root folder locations)
            csv_locations = [
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Analysis_Results", "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Analysis_Results", "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Analysis_Results", "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Analysis_Results", "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Analysis_Results", "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Analysis_Results", "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Analysis_Results", "Top_Edge_Profile_Details.csv"),
                    'BlackLine': os.path.join(self.root_folder, "BlackLine_Analysis_Results", "BlackLine_Profile_Details.csv")
                },
                {
                    'Hotpixel': os.path.join(self.root_folder, "Hotpixel_Profile_Details.csv"),
                    'CCD': os.path.join(self.root_folder, "CCD_Profile_Details.csv"),
                    'Bubble': os.path.join(self.root_folder, "Bubble_Profile_Details.csv"),
                    'LShape': os.path.join(self.root_folder, "LShape_Profile_Details.csv"),
                    'Dust': os.path.join(self.root_folder, "Dust_Profile_Details.csv"),
                    'Hiaa': os.path.join(self.root_folder, "Hiaa_Profile_Details.csv"),
                    'TopEdge': os.path.join(self.root_folder, "Top_Edge_Profile_Details.csv"),
                    'BlackLine': os.path.join(self.root_folder, "BlackLine_Profile_Details.csv")
                }
            ]
            
            # Dictionary to store data grouped by (camera, PID, pattern)
            combined_data = {}
            
            # Process each detector's CSV file
            for detector_name in ['Hotpixel', 'CCD', 'Bubble', 'LShape', 'Dust', 'Hiaa', 'TopEdge', 'BlackLine']:
                csv_path = None
                # Try all possible locations
                for location_set in csv_locations:
                    if detector_name in location_set and os.path.exists(location_set[detector_name]):
                        csv_path = location_set[detector_name]
                        break
                
                if csv_path and os.path.exists(csv_path):
                    try:
                        df = pd.read_csv(csv_path, encoding='utf-8-sig')
                        if not df.empty:
                            self.update_log.emit(f"Processing {detector_name}: {len(df)} records")

                            # Clean numpy types from the dataframe
                            df = self._clean_dataframe_columns(df)
                            
                            # Process each row
                            for index, row in df.iterrows():
                                # Get common columns
                                folder = row.get('Folder', 'Unknown')
                                file_name = row.get('File Name', 'Unknown')
                                pattern = row.get('Pattern', 'Unknown')
                                resolution = row.get('Resolution', 'Unknown')
                                
                                # Extract PID from file name
                                pid = self._extract_pid_sn(file_name)
                                
                                # Create a unique key for (camera, PID, pattern)
                                unique_key = (folder, pid, pattern)
                                
                                # Initialize if this is first time seeing this combination
                                if unique_key not in combined_data:
                                    combined_data[unique_key] = {
                                        'Camera': folder,
                                        'PID': pid,
                                        'Pattern': pattern,
                                        'Resolution': resolution,
                                        'File_Name_Original': file_name,
                                        'Status': set(),
                                        'Hotpixel_Result': "No Check",
                                        'Hotpixel_Map': "",
                                        'Hotpixel_Intesity': "",
                                        'CCD_Result': "No Check",
                                        'CCD_Map': "",
                                        'CCD_Result_NG': "No Check",
                                        'CCD_Map_NG': "",
                                        'CCD_Slope': "",
                                        'CCD_Threshold': "",
                                        'Bubble_Result': "No Check",
                                        'Bubble_Map': "",
                                        'Bubble_Value': "",
                                        'LShape_Result': "No Check",
                                        'LShape_Map': "",
                                        'LShape_Value': "",
                                        'Dust_Result': "No Check",
                                        'Dust_Map': "",
                                        'Dust_Value': "",
                                        'Hiaa_result': "No Check",
                                        'Hiaa_Map': "",
                                        'Hiaa_Value': "",
                                        'Hiaa_Threshold': "",
                                        'TopEdge_Result': "No Check",
                                        'TopEdge_Map': "",
                                        'TopEdge_Value': "",
                                        'TopEdge_Threshold': "",
                                        'BlackLine_Result': "No Check",
                                        'BlackLine_Map': "",
                                        'BlackLine_Value': "",
                                        'BlackLine_Threshold': ""
                                    }
                                
                                # Process based on detector type
                                if detector_name == "Hotpixel":
                                    # Get In_Common column from CSV
                                    in_common_val = row.get("In_Common", "OK")
                                    result_val = self._normalize_result(in_common_val)
                                    
                                    combined_data[unique_key]["Hotpixel_Result"] = result_val
                                    combined_data[unique_key]["Hotpixel_Map"] = self._safe_str(row.get("Hotpixel Position", ""))
                                    combined_data[unique_key]["Hotpixel_Intesity"] = self._format_special_values(row.get("Max Intensity", ""))
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("Hotpixel")
                                
                                elif detector_name == "CCD":
                                    status_val = row.get("Status", row.get("Has CCD", "OK"))
                                    result_val = self._normalize_result(status_val)
                                    combined_data[unique_key]["CCD_Result"] = result_val
                                    combined_data[unique_key]["CCD_Map"] = self._format_special_values(
                                        row.get("Error Positions", "")
                                    )
                                    
                                    # Get Max Slope
                                    max_slope_raw = row.get("Max Slope", None)
                                    severity_score_raw = row.get("Severity Score", None)
                                    
                                    if max_slope_raw is None or (isinstance(max_slope_raw, float) and pd.isna(max_slope_raw)):
                                        max_slope = severity_score_raw if severity_score_raw is not None else ""
                                    else:
                                        max_slope = max_slope_raw
                                    
                                    if max_slope is not None and max_slope != "" and not (isinstance(max_slope, float) and pd.isna(max_slope)):
                                        try:
                                            max_slope_float = float(max_slope)
                                            combined_data[unique_key]["CCD_Slope"] = f"{max_slope_float:.6f}"
                                        except (ValueError, TypeError):
                                            combined_data[unique_key]["CCD_Slope"] = self._format_special_values(max_slope)
                                    else:
                                        combined_data[unique_key]["CCD_Slope"] = ""
                                    
                                    combined_data[unique_key]["CCD_Threshold"] = self._format_special_values(
                                        row.get("Slope Threshold", "")
                                    )
                                    
                                    # Get In_Common column for CCD_Result_NG
                                    in_common_val = row.get("In_Common", "OK")
                                    result_ng_val = self._normalize_result(in_common_val)
                                    
                                    combined_data[unique_key]["CCD_Result_NG"] = result_ng_val
                                    
                                    # CCD_Map_NG: get error positions
                                    if result_ng_val == "NG":
                                        error_positions_str = self._format_special_values(row.get("Error Positions", ""))
                                        combined_data[unique_key]["CCD_Map_NG"] = error_positions_str
                                        combined_data[unique_key]['Status'].add("CCD")
                                
                                elif detector_name in {"Bubble", "LShape", "Dust"}:
                                    prefix = detector_name
                                    
                                    # Get Status column from CSV
                                    status_val = row.get("Status", "OK")
                                    result_val = self._normalize_result(status_val)
                                    
                                    # Debug log for LShape
                                    if prefix == "LShape" and result_val == "NG":
                                        self.update_log.emit(f"[DEBUG] {prefix}: Found NG for {file_name} (Status={status_val})")
                                    
                                    # Only update if result is NG, or if this is the first time we see this key
                                    if result_val == "NG":
                                        # Set result to NG
                                        combined_data[unique_key][f"{prefix}_Result"] = "NG"
                                        
                                        # Update Map and Value
                                        defect_positions = self._format_special_values(
                                            row.get("Defect Positions", "")
                                        )
                                        formatted_positions = self._convert_bbox_to_coordinate_pairs(defect_positions)
                                        combined_data[unique_key][f"{prefix}_Map"] = formatted_positions
                                        
                                        combined_data[unique_key][f"{prefix}_Value"] = self._format_special_values(
                                            row.get("Max Variance", "")
                                        )
                                        
                                        # Add to Status set
                                        combined_data[unique_key]['Status'].add(prefix)
                                        
                                        if prefix == "LShape":
                                            self.update_log.emit(f"[DEBUG] {prefix}: Set to NG for {folder}/{file_name}")
                                    else:
                                        # For OK records, only set if not already set (No Check)
                                        if combined_data[unique_key][f"{prefix}_Result"] == "No Check":
                                            combined_data[unique_key][f"{prefix}_Result"] = "OK"
                                            # Still update Map and Value if available
                                            defect_positions = self._format_special_values(
                                                row.get("Defect Positions", "")
                                            )
                                            formatted_positions = self._convert_bbox_to_coordinate_pairs(defect_positions)
                                            if formatted_positions:
                                                combined_data[unique_key][f"{prefix}_Map"] = formatted_positions
                                            
                                            combined_data[unique_key][f"{prefix}_Value"] = self._format_special_values(
                                                row.get("Max Variance", "")
                                            )
                                
                                elif detector_name == "Hiaa":
                                    has_hiaa = row.get("Has Hiaa", "No")
                                    result_val = self._normalize_result(has_hiaa)
                                    combined_data[unique_key]["Hiaa_result"] = result_val
                                    combined_data[unique_key]["Hiaa_Map"] = self._format_special_values(
                                        row.get("Affected Region", "")
                                    )
                                    combined_data[unique_key]["Hiaa_Value"] = self._format_special_values(
                                        row.get("D Value", "")
                                    )
                                    combined_data[unique_key]["Hiaa_Threshold"] = self._format_special_values(
                                        row.get("Threshold Used", "")
                                    )
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("Hiaa")
                                
                                elif detector_name == "TopEdge":
                                    has_topedge = row.get("Has Top_Edge", "No")
                                    result_val = self._normalize_result(has_topedge)
                                    combined_data[unique_key]["TopEdge_Result"] = result_val
                                    combined_data[unique_key]["TopEdge_Map"] = self._format_special_values(
                                        row.get("Affected Region", "")
                                    )
                                    combined_data[unique_key]["TopEdge_Value"] = self._format_special_values(
                                        row.get("D Value", "")
                                    )
                                    combined_data[unique_key]["TopEdge_Threshold"] = self._format_special_values(
                                        row.get("Threshold Used", "")
                                    )
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("TopEdge")
                                
                                elif detector_name == "BlackLine":
                                    has_blackline = row.get("Has BlackLine", "No")
                                    result_val = self._normalize_result(has_blackline)
                                    combined_data[unique_key]["BlackLine_Result"] = result_val
                                    combined_data[unique_key]["BlackLine_Map"] = self._format_special_values(
                                        row.get("Affected Region", "")
                                    )
                                    combined_data[unique_key]["BlackLine_Value"] = self._format_special_values(
                                        row.get("Outlier Percentage", "")
                                    )
                                    combined_data[unique_key]["BlackLine_Threshold"] = self._format_special_values(
                                        row.get("Threshold Used", "")
                                    )
                                    
                                    if result_val == "NG":
                                        combined_data[unique_key]['Status'].add("BlackLine")
                                                    
                    except Exception as e:
                        self.update_log.emit(f"Error processing {detector_name} CSV: {e}")
                        import traceback
                        self.update_log.emit(f"Traceback: {traceback.format_exc()}")
                else:
                    self.update_log.emit(f"CSV file not found for {detector_name}")
            
            if not combined_data:
                self.update_log.emit("No data to combine")
                return
            
            # Convert dictionary to list of rows
            rows = []
            for unique_key, data in combined_data.items():
                # Convert Status set to string for Result column
                status_list = list(data['Status'])
                
                if status_list:
                    result_status = ', '.join(sorted(status_list))
                    data['Result'] = result_status
                else:
                    data['Result'] = 'OK'
                
                # Remove the Status set (already converted to Result)
                del data['Status']
                
                # Add Date_Time column using original file name
                def get_file_datetime(camera, original_file_name):
                    """Get Modified time of TIF file and format as YYYYMMDDHHMMSS"""
                    try:
                        if not camera or not original_file_name:
                            return ""
                        
                        camera_folder = os.path.join(self.root_folder, camera)
                        if not os.path.exists(camera_folder):
                            return ""
                        
                        tif_file_path = None
                        possible_names = [
                            original_file_name,
                            original_file_name if original_file_name.endswith('.tif') else f"{original_file_name}.tif",
                            original_file_name if original_file_name.endswith('.TIF') else f"{original_file_name}.TIF"
                        ]
                        
                        for name in possible_names:
                            candidate_path = os.path.join(camera_folder, name)
                            if os.path.exists(candidate_path):
                                tif_file_path = candidate_path
                                break
                        
                        if not tif_file_path:
                            for root, dirs, files in os.walk(camera_folder):
                                for name in possible_names:
                                    candidate_path = os.path.join(root, name)
                                    if os.path.exists(candidate_path):
                                        tif_file_path = candidate_path
                                        break
                                if tif_file_path:
                                    break
                        
                        if tif_file_path and os.path.exists(tif_file_path):
                            modified_time = os.path.getmtime(tif_file_path)
                            from datetime import datetime
                            dt = datetime.fromtimestamp(modified_time)
                            return "'" + dt.strftime("%Y%m%d%H%M%S")
                        else:
                            return ""
                    except Exception as e:
                        self.update_log.emit(f"Warning: Could not get datetime for {camera}/{original_file_name}: {e}")
                        return ""
                
                # Add Date_Time column
                original_file_name = data.get('File_Name_Original', '')
                data['Date_Time'] = get_file_datetime(data.get('Camera', ''), original_file_name)
                
                # Remove temporary columns
                if 'File_Name_Original' in data:
                    del data['File_Name_Original']
                if 'Resolution' in data:
                    del data['Resolution']
                
                rows.append(data)
            
            combined_df = pd.DataFrame(rows)
            
            # Define the exact column order
            desired_columns = [
                'Camera', 'PID', 'Date_Time', 'Pattern', 'Result',
                'Hotpixel_Result', 'Hotpixel_Map', 'Hotpixel_Intesity',
                'CCD_Result', 'CCD_Map', 'CCD_Result_NG', 'CCD_Map_NG', 'CCD_Slope', 'CCD_Threshold',
                'Bubble_Result', 'Bubble_Map', 'Bubble_Value',
                'LShape_Result', 'LShape_Map', 'LShape_Value',
                'Dust_Result', 'Dust_Map', 'Dust_Value',
                'Hiaa_result', 'Hiaa_Map', 'Hiaa_Value', 'Hiaa_Threshold',
                'TopEdge_Result', 'TopEdge_Map', 'TopEdge_Value', 'TopEdge_Threshold',
                'BlackLine_Result', 'BlackLine_Map', 'BlackLine_Value', 'BlackLine_Threshold'
            ]
            
            # Create missing columns with empty values
            for col in desired_columns:
                if col not in combined_df.columns:
                    # Initialize CCD_Result_NG and CCD_Map_NG with "No Check" if not set
                    if col in ['CCD_Result_NG']:
                        combined_df[col] = "No Check"
                    else:
                        combined_df[col] = ""
            
            # Ensure Date_Time is string type
            if 'Date_Time' in combined_df.columns:
                combined_df['Date_Time'] = combined_df['Date_Time'].astype(str)
                combined_df['Date_Time'] = combined_df['Date_Time'].replace('nan', '')
            
            # Reorder DataFrame columns
            final_columns = [col for col in desired_columns if col in combined_df.columns]
            combined_df = combined_df[final_columns]
            
            # Sort by Camera -> Pattern -> PID
            sort_cols = [c for c in ['Camera', 'Pattern', 'PID'] if c in combined_df.columns]
            if sort_cols:
                combined_df = combined_df.sort_values(by=sort_cols)
            
            # Reset index
            combined_df = combined_df.reset_index(drop=True)
            
            # Apply final cleaning
            combined_df = self._clean_dataframe_columns(combined_df)
            
            # Ensure Date_Time is string after cleaning
            if 'Date_Time' in combined_df.columns:
                combined_df['Date_Time'] = combined_df['Date_Time'].astype(str)
                combined_df['Date_Time'] = combined_df['Date_Time'].replace('nan', '')
            
            # Save combined CSV file trong thư mục _Check_Result
            csv_output_path = self.summary_csv_path
            import csv
            combined_df.to_csv(csv_output_path, index=False, encoding='utf-8-sig', quoting=csv.QUOTE_ALL)

            self.update_log.emit(f"✅ Summary log CSV file saved: {csv_output_path}")
            self.update_log.emit(f"Total unique PID-Pattern combinations: {len(combined_df)}")

            self.update_log.emit(f"📁 Excel report remains in: {self.combined_path}")
            self.update_log.emit(f"📁 Log file remains in: {self.log_file_path}")
            
        except Exception as e:
            self.update_log.emit(f"Error creating combined CSV: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")
            
class DetectorStatusWidget(QWidget):
    """Compact widget for detector status"""
    def __init__(self, detector_name, parent=None):
        super().__init__(parent)
        self.detector_name = detector_name
        self.status = "pending"
        
        self.setFixedHeight(30)
        
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)
        
        # Status icon
        self.icon_label = QLabel()
        self.icon_label.setFixedSize(16, 16)
        self._update_icon()
        layout.addWidget(self.icon_label)
        
        # Detector name
        self.name_label = QLabel(detector_name)
        self.name_label.setFont(QFont("Segoe UI", 9))
        self.name_label.setStyleSheet("color: #2c3e50;")
        layout.addWidget(self.name_label)
        
        # Status text
        self.status_label = QLabel("Pending")
        self.status_label.setFont(QFont("Segoe UI", 8))
        layout.addWidget(self.status_label)
        
        layout.addStretch()
    
    def _update_icon(self):
        if self.status == "completed":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #27ae60;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("✓")
        elif self.status == "Checking":
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #3498db;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("▶")
        else:  # pending
            self.icon_label.setStyleSheet("""
                QLabel {
                    background: #95a5a6;
                    border-radius: 8px;
                    color: white;
                    font-size: 10px;
                    font-weight: bold;
                    qproperty-alignment: AlignCenter;
                }
            """)
            self.icon_label.setText("●")
    
    def update_status(self, status):
        self.status = status
        self._update_icon()
        
        if status == "completed":
            self.status_label.setText("Completed")
            self.status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
            self.name_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        elif status == "Checking":
            self.status_label.setText("Checking...")
            self.status_label.setStyleSheet("color: #3498db; font-weight: bold;")
            self.name_label.setStyleSheet("color: #3498db; font-weight: bold;")
        else:  # pending
            self.status_label.setText("Pending")
            self.status_label.setStyleSheet("color: #7f8c8d;")
            self.name_label.setStyleSheet("color: #2c3e50;")


class MainWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_app_window = parent
        self.setWindowTitle("Automatic Image Analysis Tool")
        self.resize(700, 800)  # Slightly taller for status grid
        self.setWindowIcon(QIcon(":/icons/image_analysis.png"))

        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(245, 247, 250))
        palette.setColor(QPalette.ColorRole.WindowText, QColor(52, 73, 94))
        palette.setColor(QPalette.ColorRole.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.ColorRole.Text, QColor(52, 73, 94))
        self.setPalette(palette)

        app = QApplication.instance()
        if app is not None:
            try:
                app.setQuitOnLastWindowClosed(False)
            except Exception:
                pass

        self.selected_folder = None
        self.analysis_output_folder = None
        self.detector_widgets = {}
        self.controller = None
        self.summary_results = None
        self._auto_minimize_scheduled = False

        main_layout = QVBoxLayout()
        main_layout.setSpacing(15)
        main_layout.setContentsMargins(20, 20, 20, 20)

        # Header
        header_container = QWidget()
        header_container.setObjectName("headerContainer")
        header_container.setFixedHeight(90)
        header_container.setStyleSheet("""
            #headerContainer {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 12px;
            }
        """)
        header_layout = QHBoxLayout(header_container)
        header_layout.setContentsMargins(20, 0, 20, 0)

        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))
        icon_button.setGraphicsEffect(icon_shadow)
        icon = QtGui.QIcon(":/icons/image_analysis.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70))
        header_layout.addWidget(icon_button)

        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Automatic Image Analysis Tool")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 22, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QtWidgets.QLabel("HotPixel, CCD, Bubble, LShape, Dust, Hiaa, TopEdge, BlackLine Camera defect Checker")
        subtitle_label.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)
        header_layout.addStretch()
        main_layout.addWidget(header_container)

        # Status Info - Show current folder being checked
        status_info_container = QWidget()
        status_info_container.setObjectName("statusInfoContainer")
        status_info_container.setStyleSheet("""
            #statusInfoContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        status_info_container.setGraphicsEffect(self.create_shadow_effect())
        status_info_layout = QHBoxLayout(status_info_container)
        status_info_layout.setSpacing(10)

        folder_icon = QLabel("📁")
        folder_icon.setStyleSheet("font-size: 20px;")
        status_info_layout.addWidget(folder_icon)

        self.folder_label = QLabel("Checking folders: PUC Crop Image")
        self.folder_label.setFont(QFont("Segoe UI", 10))
        self.folder_label.setStyleSheet("color: #2c3e50;")
        status_info_layout.addWidget(self.folder_label)

        status_info_layout.addStretch()

        self.status_label = QLabel("Status: Initializing...")
        self.status_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.status_label.setStyleSheet("color: #3498db;")
        status_info_layout.addWidget(self.status_label)

        main_layout.addWidget(status_info_container)

        # Detector Status Section - Compact
        status_container = QWidget()
        status_container.setObjectName("statusContainer")
        status_container.setStyleSheet("""
            #statusContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        status_container.setGraphicsEffect(self.create_shadow_effect())
        status_layout = QVBoxLayout(status_container)
        status_layout.setSpacing(0)
        
        status_header = QWidget()
        status_header_layout = QHBoxLayout(status_header)
        status_header_layout.setContentsMargins(0, 0, 0, 5)
        
        status_title = QLabel("Detector Status")
        status_title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        status_title.setStyleSheet("color: #2c3e50;")
        status_header_layout.addWidget(status_title)
        status_header_layout.addStretch()
        
        self.overall_status_label = QLabel("Overall: Checking")
        self.overall_status_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self.overall_status_label.setStyleSheet("color: #3498db;")
        status_header_layout.addWidget(self.overall_status_label)
        
        status_layout.addWidget(status_header)
        
        # Grid for detector status widgets (4 columns for compact layout)
        grid_widget = QWidget()
        grid_layout = QGridLayout(grid_widget)
        grid_layout.setHorizontalSpacing(10)
        grid_layout.setVerticalSpacing(0)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        
        detectors = ["HotPixel", "CCD", "Bubble", "LShape", "Dust", "Hiaa", "TopEdge", "BlackLine"]
        for i, detector_name in enumerate(detectors):
            widget = DetectorStatusWidget(detector_name)
            self.detector_widgets[detector_name] = widget
            row = i // 4
            col = i % 4
            grid_layout.addWidget(widget, row, col)
        
        status_layout.addWidget(grid_widget)
        main_layout.addWidget(status_container)

        # Overall Progress
        progress_container = QWidget()
        progress_container.setObjectName("progressContainer")
        progress_container.setStyleSheet("""
            #progressContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        progress_container.setGraphicsEffect(self.create_shadow_effect())
        progress_layout = QVBoxLayout(progress_container)
        progress_layout.setSpacing(0)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 1px;
                text-align: center;
                height: 25px;
                font-size: 11px;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                    stop:0 #3498db, stop:1 #2980b9);
                border-radius: 7px;
            }
        """)
        progress_layout.addWidget(self.progress_bar)
        main_layout.addWidget(progress_container)

        # Log
        log_container = QWidget()
        log_container.setObjectName("logContainer")
        log_container.setStyleSheet("""
            #logContainer {
                background: white;
                border-radius: 8px;
                padding: 15px;
            }
        """)
        log_container.setGraphicsEffect(self.create_shadow_effect())
        log_layout = QVBoxLayout(log_container)
        log_layout.setSpacing(0)
        log_header = QWidget()
        log_header_layout = QHBoxLayout(log_header)
        log_header_layout.setContentsMargins(0, 0, 0, 10)
        log_icon = QPushButton()
        log_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_MessageBoxInformation))
        log_icon.setIconSize(QSize(18, 18))
        log_icon.setFixedSize(18, 18)
        log_icon.setStyleSheet("""
            QPushButton {
                background: #f0f2f5;
                border: none;
                border-radius: 8px;
                padding: 5px;
            }
        """)
        log_header_layout.addWidget(log_icon)
        log_label = QLabel("Processing Log:")
        log_label.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        log_label.setStyleSheet("color: #2c3e50;")
        log_header_layout.addWidget(log_label)
        log_header_layout.addStretch()
        log_layout.addWidget(log_header)
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background: #f8f9fa;
                border: 2px solid #e0e0e0;
                border-radius: 8px;
                padding: 12px;
                color: #2c3e50;
                font-size: 12px;
                line-height: 1.4;
            }
        """)
        log_layout.addWidget(self.log_text)
        main_layout.addWidget(log_container)

        author_label = QLabel("Created by nguyenvanvuong1")
        author_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        author_label.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        author_label.setStyleSheet("color: #3498db; padding: 0; margin: 0;")
        main_layout.addWidget(author_label)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Start checking automatically after UI loads
        QTimer.singleShot(500, self.auto_start_checking)

    def showEvent(self, event):
        super().showEvent(event)
        if not self._auto_minimize_scheduled:
            self._auto_minimize_scheduled = True
            QTimer.singleShot(2 * 60 * 1000, self._auto_minimize_after_startup)

    def _auto_minimize_after_startup(self):
        """Minimize analysis window after 2 minutes; detectors keep running."""
        if self.isVisible():
            self.showMinimized()
            try:
                self.log_text.append("Window minimized after 2 minutes (analysis continues in background).")
            except Exception:
                pass

    def create_shadow_effect(self):
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(10)
        shadow.setXOffset(0)
        shadow.setYOffset(2)
        shadow.setColor(QColor(0, 0, 0, 25))
        return shadow

    def auto_start_checking(self):
        """Automatically start checking the PUC crop images folders"""
        self.log_text.append("🔍 Auto-detecting PUC crop folders...")
        
        # Get the directory where the script is located
        script_directory = script_dir
        
        # Define possible folder names
        puc_folders = []
        
        # Check for PUC Crop Images folder
        puc_path = os.path.join(script_directory, "PUC Crop Images")
        if os.path.exists(puc_path) and os.path.isdir(puc_path):
            puc_folders.append(puc_path)
            self.log_text.append(f"✅ Found: {puc_path}")
        else:
            self.log_text.append(f"⚠️ PUC Crop Images folder not found at: {puc_path}")
        
        
        # Also check for variations (case insensitive)
        if not puc_folders:
            # Try to find any folder containing "PUC" in the name
            all_items = os.listdir(script_directory)
            for item in all_items:
                item_path = os.path.join(script_directory, item)
                if os.path.isdir(item_path) and "PUC" in item.upper():
                    puc_folders.append(item_path)
                    self.log_text.append(f"✅ Found alternative PUC folder: {item_path}")
        
        if not puc_folders:
            # No PUC folders found
            self.log_text.append("❌ No PUC Crop Images folders found!")
            self.status_label.setText("Status: Error - No folders found")
            self.overall_status_label.setText("Overall: Failed")
            self.overall_status_label.setStyleSheet("color: #e74c3c; font-weight: bold;")
            QMessageBox.critical(self, "Error", 
                                "Could not find 'PUC Crop Images' folders in the script directory.\n\n"
                                f"Script directory: {script_directory}\n\n"
                                "Please make sure these folders exist and contain the images to check.")
            return
        
        # For now, we'll process the first found folder
        # In the future, you could modify CombinedDetectorController to handle multiple folders
        self.selected_folder = puc_folders[0]
        
        if len(puc_folders) > 1:
            self.log_text.append(f"ℹ️ Multiple PUC folders found. Processing: {self.selected_folder}")
            self.log_text.append("   (Other folders will be skipped in this version)")
        
        self.folder_label.setText(f"Checking folder: {os.path.basename(self.selected_folder)}")
        self.status_label.setText("Status: Checking...")
        
        # Start checking
        self.start_checking()

    def start_checking(self):
        if not self.selected_folder:
            return

        # Reset all detector widgets
        for detector_name, widget in self.detector_widgets.items():
            widget.update_status("pending")
        
        # Start combined detector
        self.controller = CombinedDetectorController(self.selected_folder)
        self.controller.update_progress.connect(self.update_progress)
        self.controller.update_log.connect(self.update_log)
        self.controller.update_detector_status.connect(self.update_detector_status)
        self.controller.finished.connect(self.on_finished)
        self.controller.start()

        self.overall_status_label.setText("Overall: Checking")
        self.overall_status_label.setStyleSheet("color: #3498db; font-weight: bold;")
        self.status_label.setText("Status: Running detectors...")
        self.statusBar().showMessage("Running detectors...")

    def update_progress(self, value):
        self.progress_bar.setValue(value)

    def update_detector_status(self, detector_name, status):
        """Update individual detector status widget"""
        if detector_name in self.detector_widgets:
            self.detector_widgets[detector_name].update_status(status)

    def update_log(self, message):
        self.log_text.append(message)

    def on_finished(self, results):
        self.overall_status_label.setText("Overall: Completed")
        self.overall_status_label.setStyleSheet("color: #27ae60; font-weight: bold;")
        self.status_label.setText("Status: Completed")
        self.statusBar().showMessage("Check completed")
        self.summary_results = results

        # Get the path to the Analysis_Report.xlsx file
        combined_path = None
        
        try:
            if self.controller and hasattr(self.controller, 'combined_path'):
                combined_path = self.controller.combined_path
                if os.path.exists(combined_path):
                    self.log_text.append(f"✅ Analysis report saved to: {combined_path}")
                else:
                    combined_path, _ = self._create_simple_report(results)
                    if combined_path:
                        self.log_text.append(f"✅ Simple report saved to: {combined_path}")
        except Exception as e:
            self.log_text.append(f"Error getting report: {e}")

        # Log completion message and auto-close after 2 seconds
        self.log_text.append("\n" + "="*50)
        self.log_text.append("✅ ALL CHECKS COMPLETED SUCCESSFULLY!")
        self.log_text.append(f"📊 Reports saved in: {self.controller.output_root_dir}")
        self.log_text.append("="*50)
        self.log_text.append("🔄 Closing analysis window in 2 seconds...")
        
        # Auto-close after 2 seconds
        QTimer.singleShot(2000, self.close)

    def _read_table_from_excel(self, excel_path):
        """Read data from existing Excel file"""
        try:
            from openpyxl import load_workbook
            wb = load_workbook(excel_path)
            if "Summary" not in wb.sheetnames:
                return []
            
            ws = wb["Summary"]
            table_rows = []
            
            # Skip header (row 1)
            for row in ws.iter_rows(min_row=2, values_only=True):
                if row[0]:  # Only add if detector name exists
                    table_rows.append([row[0], row[1], row[2] or ""])
            
            return table_rows
        except Exception as e:
            self.log_text.append(f"Error reading Excel: {e}")
            return []

    def _create_simple_report(self, results):
        """Create simple report if controller didn't create file"""
        try:
            root = getattr(self.controller, "run_output_folder", self.selected_folder)
            if not root:
                return None, []
            
            combined_path = os.path.join(root, "Analysis_Report.xlsx")
            
            # Create simple workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "Summary"
            
            headers = ["Detector", "Total Camera", "Camera List"]
            ws.append(headers)
            
            # Count total cameras
            total_cameras = 0
            if os.path.exists(root):
                total_cameras = len([f for f in os.listdir(root) if os.path.isdir(os.path.join(root, f)) 
                                    and f not in ["Hotpixel_Analysis_Results", "CCD_Analysis_Results", "Dust_Analysis_Results", "Hiaa_Analysis_Results",
                                                  "Bubble_Analysis_Results", "LShape_Analysis_Results", "Top_Edge_Analysis_Results", "BlackLine_Analysis_Results"]])
            
            table_rows = []
            detectors = [
                ("HotPixel Checking", results.get('hotpixel', [])),
                ("CCD Checking", results.get('ccd', [])),
                ("Bubble Checking", results.get('bubble', [])),
                ("LShape", results.get('lshape', [])),
                ("Dust", results.get('dust', [])),
                ("Hiaa", results.get('hiaa', [])),
                ("TopEdge", results.get('topedge', [])),
                ("BlackLine", results.get('blackline', []))
            ]
            
            for name, folders in detectors:
                folders_sorted = sorted(set(folders)) if folders else []
                error_count = len(folders_sorted)
                camera_count_text = f"{error_count} / {total_cameras}" if total_cameras > 0 else str(error_count)
                camera_list_text = "\n".join(folders_sorted) if folders_sorted else ""
                
                ws.append([name, camera_count_text, camera_list_text])
                table_rows.append([name, camera_count_text, camera_list_text])
            
            # Save file
            wb.save(combined_path)
            self.log_text.append(f"Simple report saved: {combined_path}")
            
            return combined_path, table_rows
            
        except Exception as e:
            self.log_text.append(f"Error creating simple report: {e}")
            return None, []

    def closeEvent(self, event):
        if self.main_app_window:
            self.main_app_window.setEnabled(True)
            self.main_app_window.remove_blur_effect()
        super().closeEvent(event)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())