import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None


def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF


def _get_blackline_config(img_width, img_height, file_name):
    """
    Read BlackLine_* positions/threshold from settings.csv for given resolution and pattern.
    Returns dict with keys: x1, y1, x2, y2, threshold, ptn_list.
    """
    df = _load_settings_df()
    if df is None:
        return {}

    resolution_key = f"{img_width};{img_height}"
    candidates = df

    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]

    if candidates.empty:
        return {}

    # Get the first matching resolution row
    row = candidates.iloc[0]

    def _get_float(col):
        if col not in row or pd.isna(row[col]) or row[col] == "":
            return None
        try:
            return float(row[col])
        except Exception:
            return None

    def _get_str(col):
        if col not in row or pd.isna(row[col]):
            return ""
        return str(row[col])

    cfg = {}
    # Parse BlackLine_re1 and BlackLine_re2 (format: "x;y" or "x1;y1-x2;y2")
    re1_str = _get_str("BlackLine_re1")
    re2_str = _get_str("BlackLine_re2")
    
    if re1_str and re2_str:
        try:
            # Parse re1: "x1;y1"
            parts1 = re1_str.split(';')
            if len(parts1) == 2:
                x1 = int(float(parts1[0].strip()))
                y1 = int(float(parts1[1].strip()))
                cfg["x1"] = x1
                cfg["y1"] = y1
            
            # Parse re2: "x2;y2"
            parts2 = re2_str.split(';')
            if len(parts2) == 2:
                x2 = int(float(parts2[0].strip()))
                y2 = int(float(parts2[1].strip()))
                cfg["x2"] = x2
                cfg["y2"] = y2
        except Exception:
            pass
    
    thr = _get_float("BlackLine_Threshold")
    if thr is not None:
        cfg["threshold"] = thr
    
    # Parse pattern list from semicolon-separated string
    ptn_check_str = _get_str("BlackLine_PTN_Check")
    if ptn_check_str:
        # Split by semicolon and filter out empty strings
        ptn_list = [p.strip() for p in ptn_check_str.split(';') if p.strip()]
        cfg["ptn_list"] = ptn_list

    return cfg


def is_pattern_in_csv(file_name, resolution_key):
    """
    Check if the file's pattern exists in BlackLine_PTN_Check for the given resolution.
    Returns True if pattern should be checked, False otherwise.
    """
    df = _load_settings_df()
    if df is None:
        return False

    # Find row with matching resolution
    if "Display_Resolution" in df.columns:
        res_series = df["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if not mask_res.any():
            return False
        row = df[mask_res].iloc[0]
    else:
        return False

    # Get pattern list from BlackLine_PTN_Check column
    if "BlackLine_PTN_Check" not in row or pd.isna(row["BlackLine_PTN_Check"]):
        return False
    
    ptn_check_str = str(row["BlackLine_PTN_Check"])
    ptn_list = [p.strip() for p in ptn_check_str.split(';') if p.strip()]
    
    # Check if any pattern in the list matches the filename
    for pattern in ptn_list:
        if pattern and pattern.lower() in file_name.lower():
            return True
    
    return False


def calculate_blackline_metrics(img, roi_config=None):
    """
    Calculate metrics for blackline detection using boxplot method
    Returns: outlier_percentage and intensity values
    """
    if not (roi_config and all(k in roi_config for k in ("x1", "y1", "x2", "y2"))):
        raise ValueError(
            "Missing BlackLine_re1/re2 ROI config in settings.csv for this resolution/pattern; skip image."
        )

    # Extract ROI
    x1, y1, x2, y2 = roi_config["x1"], roi_config["y1"], roi_config["x2"], roi_config["y2"]
    roi = img[y1:y2, x1:x2]
    
    # Calculate average intensity for each row in the ROI
    row_avg_intensities = np.mean(roi, axis=1)
    
    # Calculate statistics for boxplot
    Q1 = np.percentile(row_avg_intensities, 25)
    Q3 = np.percentile(row_avg_intensities, 75)
    IQR = Q3 - Q1
    
    # Define outlier boundaries (1.5 * IQR is standard for boxplot)
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    # Count outliers
    outliers = row_avg_intensities[(row_avg_intensities < lower_bound) | (row_avg_intensities > upper_bound)]
    outlier_count = len(outliers)
    total_rows = len(row_avg_intensities)
    outlier_percentage = (outlier_count / total_rows) * 100 if total_rows > 0 else 0
    
    return outlier_percentage, row_avg_intensities, Q1, Q3, IQR, lower_bound, upper_bound, outlier_count, total_rows


def detect_blackline_by_profile(image_path, file_name=None):
    """
    Blackline detection based on row intensity analysis using boxplot method
    """
    # Reading 16-bit images
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # If the image has many channels, convert it to grayscale
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    img_height, img_width = img.shape[:2]
    resolution_key = f"{img_width};{img_height}"
    
    # Check if this file's pattern should be processed based on CSV
    if not is_pattern_in_csv(file_name, resolution_key):
        raise ValueError(f"Pattern in {file_name} not found in BlackLine_PTN_Check for resolution {resolution_key}; skipping.")
    
    cfg = _get_blackline_config(img_width, img_height, file_name)

    # Require threshold from CSV; if missing, skip by raising for caller to log
    if not cfg or "threshold" not in cfg:
        raise ValueError(
            f"No BlackLine_Threshold found in settings.csv for resolution {resolution_key} (file: {os.path.basename(file_name) if file_name else 'unknown'})"
        )
    dynamic_threshold = cfg["threshold"]

    # Calculate metrics
    outlier_percentage, row_avg_intensities, Q1, Q3, IQR, lower_bound, upper_bound, outlier_count, total_rows = calculate_blackline_metrics(
        img,
        roi_config=cfg if cfg else None,
    )
    
    # Determine if there is a blackline
    has_blackline = outlier_percentage > dynamic_threshold
    
    # Determine the ROI for visualization / mask
    affected_roi_coords = None
    if has_blackline:
        if cfg and all(k in cfg for k in ("x1", "y1", "x2", "y2")):
            # Use exact positions from settings.csv
            x1 = cfg["x1"]
            y1 = cfg["y1"]
            x2 = cfg["x2"]
            y2 = cfg["y2"]
            affected_roi_coords = (x1, y1, x2, y2)
    
    # Create visualization - MARK THE DEFECT AREA
    result = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
    
    # Add resolution information to the log
    resolution_info = f"{img_width}x{img_height}"
    
    # Only draw the faulty area if a blackline is present
    if has_blackline and affected_roi_coords:
        x1, y1, x2, y2 = affected_roi_coords
        # Draw a red rectangle for the affected area
        cv2.rectangle(result, (x1, y1), (x2, y2), (0, 0, 255), 4)
        # Add text indicating which areas are affected and their resolution
        region_text = f"BlackLine Detected (Outlier%={outlier_percentage:.2f}%, Thresh={dynamic_threshold}%) - {resolution_info}"
        cv2.putText(result, region_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        # Add statistics
        stats_text = f"Outliers: {outlier_count}/{total_rows} rows | Q1={Q1:.1f}, Q3={Q3:.1f}, IQR={IQR:.1f}"
        cv2.putText(result, stats_text, (10, 65), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 1)
    else:
        # If there is no blackline, display the message OK
        status_text = f"No BlackLine (Outlier%={outlier_percentage:.2f}%, Thresh={dynamic_threshold}%) - {resolution_info}"
        cv2.putText(result, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
    
    # Apply a mask to the affected area (if have)
    if has_blackline and affected_roi_coords:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
        x1, y1, x2, y2 = affected_roi_coords
        mask[y1:y2, x1:x2] = 255
    else:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
    return result, mask, outlier_percentage, has_blackline, affected_roi_coords, row_avg_intensities, Q1, Q3, IQR, outlier_count, total_rows, dynamic_threshold


def _get_blackline_ptn_list_for_resolution(img_width, img_height):
    """
    Get the list of patterns from the BlackLine_PTN_Check column.
    """
    df = _load_settings_df()
    if df is None or "BlackLine_PTN_Check" not in df.columns:
        return []

    candidates = df
    resolution_key = f"{img_width};{img_height}"
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return []

    out = []
    for val in candidates["BlackLine_PTN_Check"].dropna().astype(str):
        for p in val.split(";"):
            p = p.strip()
            if p and p not in out:
                out.append(p)
    return out


def _extract_blackline_pattern_and_group_key(file_name, img_width, img_height):
    """
    Check if the filename contains any of the terms in BlackLine_PTN_Check.
    Returns (matched_pattern, group_key) or (None, None).
    """
    if not file_name:
        return None, None
    ptn_list = _get_blackline_ptn_list_for_resolution(img_width, img_height)
    if not ptn_list:
        return None, None
    fname = str(file_name)
    for ptn in ptn_list:
        if ptn and ptn in fname:
            return ptn, ptn
    return None, None


def extract_pattern(file_name, img_width=None, img_height=None):
    """Returns the BlackLine pattern if the filename contains it; otherwise, None."""
    if img_width is None or img_height is None:
        return None
    ptn, _ = _extract_blackline_pattern_and_group_key(file_name, img_width, img_height)
    return ptn


def check_for_blackline_in_folder(blackline_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_blackline_dir, crop_blackline_dir):
    """
    Check BlackLine in the folder - Catch errors immediately upon detection
    """
    base_folder_name = os.path.basename(folder_path)
    blackline_files = []  # List to track which files have blackline
    blackline_results = []  # Store results for files with blackline
    profile_data_list = []  # Store profile data for CSV export
    
    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        # Use the detect_blackline_by_profile function
        try:
            result, mask, outlier_percentage, has_blackline, affected_roi_coords, row_avg_intensities, Q1, Q3, IQR, outlier_count, total_rows, used_threshold = detect_blackline_by_profile(
                file_path, file_name=file_name
            )
        except Exception as e:
            blackline_checker_thread.update_log.emit(f"Error processing {file_name}: {str(e)}")
            continue

        # Extract resolution information from the image
        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is not None:
            img_height, img_width = img.shape[:2]
            resolution = f"{img_width}x{img_height}"
        else:
            resolution = "Unknown"

        # Format affected region coordinates for CSV
        affected_region = ""
        if has_blackline and affected_roi_coords:
            x1, y1, x2, y2 = affected_roi_coords
            affected_region = f"({x1},{y1})-({x2},{y2})"
        
        # Calculate statistics for profile data
        mean_intensity = np.mean(row_avg_intensities) if len(row_avg_intensities) > 0 else 0
        std_intensity = np.std(row_avg_intensities) if len(row_avg_intensities) > 0 else 0
        min_intensity = np.min(row_avg_intensities) if len(row_avg_intensities) > 0 else 0
        max_intensity = np.max(row_avg_intensities) if len(row_avg_intensities) > 0 else 0
        
        # Save profile information to CSV
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Resolution": resolution,
            "Outlier Percentage": outlier_percentage,
            "Outlier Count": outlier_count,
            "Total Rows": total_rows,
            "Q1": Q1,
            "Q3": Q3,
            "IQR": IQR,
            "Mean Intensity": mean_intensity,
            "Std Intensity": std_intensity,
            "Min Intensity": min_intensity,
            "Max Intensity": max_intensity,
            "Threshold Used": used_threshold,
            "Has BlackLine": "Yes" if has_blackline else "No",
            "Affected Region": affected_region,
            "Status": "BlackLine Found" if has_blackline else "OK"
        })

        # Save mask image for files with blackline
        if has_blackline:
            mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
            cv2.imwrite(mask_img_path, mask)
        
        # If BlackLine is available, save the information
        if has_blackline:
            blackline_files.append(file_name)
            
            # Save original image
            original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
            if original_img is not None:
                original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                if len(original_img_norm.shape) == 3:
                    original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
            else:
                original_img_norm = np.zeros((100, 100), dtype=np.uint8)  # Fallback
            
            # Define cropping area - TAKEN FROM ROI COORDS
            if has_blackline and affected_roi_coords:
                crop_coords = affected_roi_coords
            else:
                # This should not happen if has_blackline is True
                crop_coords = (0, 150, 30, 1150)
            
            blackline_results.append({
                "file_name": file_name,
                "original_img": original_img_norm,
                "result_img": result,
                "outlier_percentage": outlier_percentage,
                "crop_coords": crop_coords,
                "used_threshold": used_threshold,
                "profile_data": profile_data_list[-1]  # Reference to the last added profile data
            })
    
    # If at least one file has blackline
    if blackline_results:
        # Create a result image with all files that have blackline
        base_result = blackline_results[0]["result_img"]
        
        # Save result image
        aggregated_result_img_path = os.path.join(mark_blackline_dir, f"{base_folder_name}_{pattern}_blackline_result.png")
        cv2.imwrite(aggregated_result_img_path, base_result)
        
        # Create cropped images for each blackline-affected file
        individual_cropped_image_paths = []
        for idx, blackline_info in enumerate(blackline_results):
            crop_coords = blackline_info["crop_coords"]
            original_img = blackline_info["original_img"]
            
            x1, y1, x2, y2 = crop_coords
            # Add padding to cropped images
            padding = int(50 * (original_img.shape[0] / 1320.0))  # Adjust padding according to resolution
            crop_x_start = max(0, x1 - padding)
            crop_y_start = max(0, y1 - padding)
            crop_x_end = min(original_img.shape[1], x2 + padding)
            crop_y_end = min(original_img.shape[0], y2 + padding)
            
            cropped_img = original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            # Create a cropped filename with threshold information
            cropped_filename = f"{base_folder_name}_{pattern}_Outlier{blackline_info['outlier_percentage']:.2f}%_Thresh{blackline_info['used_threshold']}_{idx+1}_cropped.png"
            individual_cropped_img_path = os.path.join(crop_blackline_dir, cropped_filename)
            cv2.imwrite(individual_cropped_img_path, cropped_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)
        
        blackline_checker_thread.update_log.emit(f"Found blackline in {len(blackline_files)} files for pattern {pattern} in folder {base_folder_name}")
        
        # Returns report entries
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        
        return True, report_entries, profile_data_list
    else:
        # No files have blackline
        return False, None, profile_data_list


def generate_excel_report(blackline_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "BlackLine Report"
    # Prepare Summary workbook and sheet
    output_base = blackline_checker_thread.summary_output_folder if hasattr(blackline_checker_thread, 'summary_output_folder') and blackline_checker_thread.summary_output_folder else os.path.dirname(output_dir)
    summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "BlackLine Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["BlackLine Report"]
        # Clear old content by removing and recreating
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("BlackLine Report")
    else:
        summary_ws = summary_wb.create_sheet("BlackLine Report")

    # Determine the maximum number of cropped images to create dynamic column headers
    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    # Add headers
    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    # Set fixed column widths
    sheet.column_dimensions['A'].width = 25  # Folder
    sheet.column_dimensions['B'].width = 20  # PTN
    sheet.column_dimensions['C'].width = 20  # Status
    sheet.column_dimensions['D'].width = 45  # Original Image with Mark
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 20
    summary_ws.column_dimensions['D'].width = 45

    # Scale factor for images when embedding into Excel
    scale_factor = 0.25 

    # Alternating background colors for rows with the same folder name
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    # Separate reports into two groups: with errors and without errors
    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "BlackLine Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    # Combine: errors first, then no errors
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "BlackLine Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        # Insert aggregated result image into column D
        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * blackline_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * blackline_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        # Insert individual cropped images into dynamic columns starting from column E
        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "BlackLine_Detection_Report.xlsx")
    workbook.save(excel_file_path)
    # Save/Commit Summary workbook
    summary_wb.save(summary_path)
    
    # Create a CSV file containing profile details
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "BlackLine_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability
        column_order = [
            "Folder", "File Name", "Pattern", "Resolution", "Status", "Has BlackLine",
            "Outlier Percentage", "Outlier Count", "Total Rows", "Threshold Used",
            "Q1", "Q3", "IQR", "Mean Intensity", "Std Intensity", 
            "Min Intensity", "Max Intensity", "Affected Region"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder and File Name
        df = df.sort_values(by=["Folder", "File Name"])
        
        # Save file CSV
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        blackline_checker_thread.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
        blackline_checker_thread.update_log.emit(f"Total records in CSV: {len(df)}")
    
    try:
        blackline_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'BlackLine Report'")
    except Exception:
        pass


# New class for running analysis in the background thread.
class BlackLineCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "BlackLine_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18 # Set constant here

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder  # Folder for Analysis_Report.xlsx
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_blackline_dir = os.path.join(self.analysis_output_folder, "mark_blackline")
        self.crop_blackline_dir = os.path.join(self.analysis_output_folder, "crop_blackline")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_blackline_dir, exist_ok=True)
        os.makedirs(self.crop_blackline_dir, exist_ok=True)
        self.temp_files_to_delete = [] # Initialize list for temporary files
        self.all_profile_data = []  # Store all profile data for CSV export

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths: # If TIFF images are found directly in the folder (excluding _ori.tif)
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        # If no direct TIFF images, search subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path: # Skip the root folder itself
                continue
            
            # Filter files for .tif and exclude _ori.tif
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files: # If any relevant TIFF files found in subfolder
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    
                    # Create new name: Parent_Subfolder_Name_Original_File_Name.tif
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path) # Add to deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            grouped_reports = []
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "BlackLine_Analysis_Results"]
            # Get a list of subfolders in the root folder
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Prepare images for analysis: copy from subfolders if necessary
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                # Determine resolution once per folder (assumption: same resolution within a camera folder)
                folder_img_w = None
                folder_img_h = None
                for _p in image_paths_for_analysis:
                    _img = cv2.imread(_p, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
                    if _img is not None:
                        folder_img_h, folder_img_w = _img.shape[:2]
                        break

                grouped_files_by_position = {}
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        pattern, group_key = _extract_blackline_pattern_and_group_key(file_name, folder_img_w, folder_img_h)
                        if pattern and group_key:
                            if group_key not in grouped_files_by_position:
                                grouped_files_by_position[group_key] = []
                            grouped_files_by_position[group_key].append(file_name)

                if not grouped_files_by_position:
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid pattern found",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                for group_key, file_names_in_group in grouped_files_by_position.items():
                    blackline_found_in_group, report_entries, profile_data_list = check_for_blackline_in_folder(
                        self,
                        folder_path, file_names_in_group, group_key,
                        self.mask_images_dir, self.mark_blackline_dir, self.crop_blackline_dir,
                    )
                    
                    self.all_profile_data.extend(profile_data_list)
                    if blackline_found_in_group:
                        cropped_list = [entry["cropped_img_path"] for entry in (report_entries or []) if entry.get("cropped_img_path")]
                        result_image = report_entries[0]["result_img_path"] if report_entries else None
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "BlackLine Found",
                            "Result_Image": result_image,
                            "Cropped_Images": cropped_list
                        })
                    else:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "No blackline detected",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            # Debug: Display information about profile data
            if self.all_profile_data:
                self.update_log.emit(f"Total profile records collected: {len(self.all_profile_data)}")
                
                # Analyze pattern distribution
                pattern_counts = {}
                for data in self.all_profile_data:
                    pattern = data.get("Pattern", "Unknown")
                    pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
                
                self.update_log.emit("Pattern distribution in profile data:")
                for pattern, count in pattern_counts.items():
                    self.update_log.emit(f"  {pattern}: {count} files")
                
                # Analyze step distributions
                step_counts = {}
                for data in self.all_profile_data:
                    file_name = data.get("File Name", "")
                    step_match = re.search(r'step0([1-9])', file_name, re.IGNORECASE)
                    if step_match:
                        step = step_match.group(0)
                        step_counts[step] = step_counts.get(step, 0) + 1
                
                self.update_log.emit("Step distribution in profile data:")
                for step, count in step_counts.items():
                    self.update_log.emit(f"  {step}: {count} files")
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated.")
                
                blackline_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "BlackLine Found"))
                self.finished.emit(blackline_folders)
            else:
                # Still create CSV if profile data is available.
                if self.all_profile_data:
                    csv_file_path = os.path.join(self.analysis_output_folder, "BlackLine_Profile_Details.csv")
                    df = pd.DataFrame(self.all_profile_data)
                    
                    # Arrange the columns for easier reading
                    column_order = [
                        "Folder", "File Name", "Pattern", "Resolution", "Status", "Has BlackLine",
                        "Outlier Percentage", "Outlier Count", "Total Rows", "Threshold Used",
                        "Q1", "Q3", "IQR", "Mean Intensity", "Std Intensity", 
                        "Min Intensity", "Max Intensity", "Affected Region"
                    ]
                    # Only retain the columns present in the DataFrame
                    available_columns = [col for col in column_order if col in df.columns]
                    df = df[available_columns]
                    
                    # Sort by Folder and File Name
                    df = df.sort_values(by=["Folder", "File Name"])
                    
                    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                    self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
                    self.update_log.emit(f"Total records in CSV: {len(df)}")
                
                self.update_log.emit("Analysis complete! No folders with blackline, but CSV file generated.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")
            self.finished.emit([])
        finally:
            # Clean up temporary copied files
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()