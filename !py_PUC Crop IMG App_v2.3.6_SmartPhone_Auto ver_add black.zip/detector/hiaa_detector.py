import cv2
import numpy as np
import os
import re
import math
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill, Font, Border, Side, Alignment
import sys
from PIL import Image 
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QWidget, QPushButton, QLabel,
    QTextEdit, QFileDialog, QProgressBar, QMessageBox, QHBoxLayout,
    QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import rc.icons 
from PyQt6 import QtCore, QtGui, QtWidgets 
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None


def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF


def _get_hiaa_config(img_width, img_height, file_name):
    """
    Read Hiaa_* config (positions and thresholds) from settings.csv for given resolution and pattern.
    Returns dict with keys: y1, y2, top_x1, top_x2, bot_x1, bot_x2, nor_x1, nor_x2, 
    threshold, threshold2, ptn_check1, ptn_check2.
    """
    df = _load_settings_df()
    if df is None:
        return {}

    resolution_key = f"{img_width};{img_height}"
    candidates = df

    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]

    if candidates.empty:
        return {}

    row = candidates.iloc[0]

    def _get_float(col):
        if col not in row or pd.isna(row[col]) or row[col] == "":
            return None
        try:
            return float(row[col])
        except Exception:
            return None

    def _get_str(col):
        if col not in row or pd.isna(row[col]) or row[col] == "":
            return None
        return str(row[col])

    cfg = {}
    y1 = _get_float("Hiaa_Pos_Y1")
    y2 = _get_float("Hiaa_Pos_Y2")
    top_x1 = _get_float("Hiaa_Pos_Top_X1")
    top_x2 = _get_float("Hiaa_Pos_Top_X2")
    bot_x1 = _get_float("Hiaa_Pos_Bot_X1")
    bot_x2 = _get_float("Hiaa_Pos_Bot_X2")
    nor_x1 = _get_float("Hiaa_Pos_Nor_X1")
    nor_x2 = _get_float("Hiaa_Pos_Nor_X2")
    
    # Read 2 thresholds
    thr1 = _get_float("Hiaa_Threshold")
    thr2 = _get_float("Hiaa_Threshold_2")
    
    # Read 2 PTN check lists
    ptn1 = _get_str("Hiaa_PTN_Check")
    ptn2 = _get_str("Hiaa_PTN_Check_2")

    if y1 is not None and y2 is not None:
        cfg["y1"] = int(round(y1))
        cfg["y2"] = int(round(y2))
    if top_x1 is not None and top_x2 is not None:
        cfg["top_x1"] = int(round(top_x1))
        cfg["top_x2"] = int(round(top_x2))
    if bot_x1 is not None and bot_x2 is not None:
        cfg["bot_x1"] = int(round(bot_x1))
        cfg["bot_x2"] = int(round(bot_x2))
    if nor_x1 is not None and nor_x2 is not None:
        cfg["nor_x1"] = int(round(nor_x1))
        cfg["nor_x2"] = int(round(nor_x2))
    
    # Save thresholds
    if thr1 is not None:
        cfg["threshold"] = thr1
    if thr2 is not None:
        cfg["threshold2"] = thr2
        
    # Save PTN lists
    if ptn1 is not None:
        cfg["ptn_check1"] = ptn1
    if ptn2 is not None:
        cfg["ptn_check2"] = ptn2

    return cfg


def calculate_profile_metrics(img, roi_config=None):
    """
    Calculate profile metrics for hiaa detection
    Returns: D value and profile information
    """
    # Get image resolution
    img_height, img_width = img.shape[:2]

    # The ROI must be retrieved from settings.csv.
    if not (roi_config and all(k in roi_config for k in ("y1", "y2", "top_x1", "top_x2", "bot_x1", "bot_x2", "nor_x1", "nor_x2"))):
        raise ValueError(
            "Missing Hiaa_Pos_* ROI config in settings.csv for this resolution/pattern; skip image."
        )

    y1_profile = roi_config["y1"]
    y2_profile = roi_config["y2"]
    top_profile_roi = img[y1_profile:y2_profile, roi_config["top_x1"]:roi_config["top_x2"]]
    bottom_profile_roi = img[y1_profile:y2_profile, roi_config["bot_x1"]:roi_config["bot_x2"]]
    normal_profile_roi = img[y1_profile:y2_profile, roi_config["nor_x1"]:roi_config["nor_x2"]]
    
    # Calculate the average for each column for each profile
    top_profile_avg = np.mean(top_profile_roi, axis=0)
    bottom_profile_avg = np.mean(bottom_profile_roi, axis=0)
    normal_profile_avg = np.mean(normal_profile_roi)
    
    # Calculate D = (min(min(TProfile), min(BProfile))) / Avg(Normal)
    min_top = np.min(top_profile_avg)
    min_bottom = np.min(bottom_profile_avg)
    min_profile = min(min_top, min_bottom)
    
    D = min_profile / normal_profile_avg if normal_profile_avg > 0 else 0
    
    # Calculate the average value of each profile
    avg_top = np.mean(top_profile_avg)
    avg_bottom = np.mean(bottom_profile_avg)
    avg_normal = normal_profile_avg
    
    return D, min_top, min_bottom, normal_profile_avg, avg_top, avg_bottom, avg_normal, img_height, img_width


def _get_hiaa_ptn_list_for_resolution(img_width, img_height):
    """
    Get the list of laboratories from the Hiaa_PTN_Check and Hiaa_PTN_Check_2 columns.
    Returns a list of unique laboratories from both columns.
    """
    df = _load_settings_df()
    if df is None:
        return []

    candidates = df
    resolution_key = f"{img_width};{img_height}"
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return []

    out = []
    # Take from the first column
    if "Hiaa_PTN_Check" in candidates.columns:
        for val in candidates["Hiaa_PTN_Check"].dropna().astype(str):
            for p in val.split(";"):
                p = p.strip()
                if p and p not in out:
                    out.append(p)
    
    # Take from the second column
    if "Hiaa_PTN_Check_2" in candidates.columns:
        for val in candidates["Hiaa_PTN_Check_2"].dropna().astype(str):
            for p in val.split(";"):
                p = p.strip()
                if p and p not in out:
                    out.append(p)
                    
    return out


def _extract_hiaa_pattern_and_group_key(file_name, img_width, img_height):
    """
    Check if the filename contains any of the terms in Hiaa_PTN_Check or Hiaa_PTN_Check_2.
    Returns (matched_pattern, group_key) or (None, None).
    Group_key will include information on both the pattern and the source column for differentiation.
    """
    if not file_name:
        return None, None
    
    df = _load_settings_df()
    if df is None:
        return None, None
        
    resolution_key = f"{img_width};{img_height}"
    candidates = df
    
    if "Display_Resolution" in candidates.columns:
        res_series = candidates["Display_Resolution"].astype(str)
        mask_res = res_series == resolution_key
        if mask_res.any():
            candidates = candidates[mask_res]
        else:
            return None, None
    
    if candidates.empty:
        return None, None
        
    row = candidates.iloc[0]
    fname = str(file_name)
    
    # Check the first column
    if "Hiaa_PTN_Check" in candidates.columns and pd.notna(row.get("Hiaa_PTN_Check")):
        ptn_list1 = str(row["Hiaa_PTN_Check"]).split(";")
        for ptn in ptn_list1:
            ptn = ptn.strip()
            if ptn and ptn in fname:
                return ptn, f"{ptn}_col1"
    
    # Check the second column
    if "Hiaa_PTN_Check_2" in candidates.columns and pd.notna(row.get("Hiaa_PTN_Check_2")):
        ptn_list2 = str(row["Hiaa_PTN_Check_2"]).split(";")
        for ptn in ptn_list2:
            ptn = ptn.strip()
            if ptn and ptn in fname:
                return ptn, f"{ptn}_col2"
    
    return None, None


def extract_pattern(file_name, img_width=None, img_height=None):
    """Returns the pattern Hiaa (e.g., step01_0300NIT_B192) if the filename contains it; otherwise, None."""
    if img_width is None or img_height is None:
        return None
    ptn, _ = _extract_hiaa_pattern_and_group_key(file_name, img_width, img_height)
    return ptn


def detect_hiaa_by_profile(image_path, file_name=None):
    """
    Hiaa detection based on profile analysis
    Use the appropriate threshold based on the laboratory column the file belongs to.
    """
    # Read image 16-bit
    img = cv2.imread(image_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
    
    if img is None:
        raise ValueError(f"Cannot read image: {image_path}")
    
    # If the image has many channels, convert it to grayscale
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Get configuration from settings.csv
    img_height, img_width = img.shape[:2]
    cfg = _get_hiaa_config(img_width, img_height, file_name)

    if not cfg:
        resolution_key = f"{img_width};{img_height}"
        raise ValueError(
            f"No Hiaa config found in settings.csv for resolution {resolution_key} (file: {os.path.basename(file_name) if file_name else 'unknown'})"
        )
    
    # Determine the threshold based on the file pattern.
    dynamic_threshold = None
    if file_name:
        # Check which laboratory column the file belongs to.
        pattern, group_key = _extract_hiaa_pattern_and_group_key(file_name, img_width, img_height)
        if group_key and group_key.endswith("_col2") and "threshold2" in cfg:
            dynamic_threshold = cfg["threshold2"]
        elif "threshold" in cfg:
            dynamic_threshold = cfg["threshold"]
    
    # Fallback if it cannot be determined
    if dynamic_threshold is None:
        if "threshold" in cfg:
            dynamic_threshold = cfg["threshold"]
        elif "threshold2" in cfg:
            dynamic_threshold = cfg["threshold2"]
        else:
            resolution_key = f"{img_width};{img_height}"
            raise ValueError(
                f"No Hiaa_Threshold found in settings.csv for resolution {resolution_key} (file: {os.path.basename(file_name) if file_name else 'unknown'})"
            )
    
    # Calculate metrics
    D, min_top, min_bottom, normal_avg, avg_top, avg_bottom, avg_normal, img_height, img_width = calculate_profile_metrics(
        img,
        roi_config=cfg,
    )
    
    # Determine if you have HIA - USE DYNAMIC THRESHOLD
    has_hiaa = D <= dynamic_threshold
    
    # Determine the scale factor to adjust the ROI for error detection
    if img_height == 1320 and img_width == 2868:
        # for 2868x1320
        y1_profile = 608
        y2_profile = 848
        scale_y = 1.0
    elif img_height == 1206 and img_width == 2622:
        # for 2622x1206
        y1_profile = 511
        y2_profile = 791
        scale_y = 1206 / 1320.0
    else:
        # Calculate scale factor
        scale_y = img_height / 1320.0
        y1_profile = int(608 * scale_y)
        y2_profile = int(848 * scale_y)
    
    # Identify the affected area (top or bottom) and define the ROI for that area
    affected_region = None
    affected_roi_coords = None
    if has_hiaa:
        # Identify which region has a smaller minimum value
        if min_top <= min_bottom:
            affected_region = "top"
            # The origin coordinates for a 1320 pixel height are: (20,508; 50,948)
            x1 = int(20 * (img_width / 2868.0))
            x2 = int(50 * (img_width / 2868.0))
            y1 = int(508 * scale_y)
            y2 = int(948 * scale_y)
            affected_roi_coords = (x1, y1, x2, y2)
        else:
            affected_region = "bottom"
            # The origin coordinates for a 1320 pixel height are: (142,508; 172,948)
            x1 = int(142 * (img_width / 2868.0))
            x2 = int(172 * (img_width / 2868.0))
            y1 = int(508 * scale_y)
            y2 = int(948 * scale_y)
            affected_roi_coords = (x1, y1, x2, y2)
    
    # Create visualization
    result = cv2.normalize(img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    result = cv2.cvtColor(result, cv2.COLOR_GRAY2BGR)
    
    # Add resolution information to the log
    resolution_info = f"{img_width}x{img_height}"
    
    # Determine the threshold source for display.
    threshold_source = ""
    if file_name:
        pattern, group_key = _extract_hiaa_pattern_and_group_key(file_name, img_width, img_height)
        if group_key and group_key.endswith("_col2"):
            threshold_source = " (Threshold 2)"
    
    # Only draw defect region if have hiaa
    if has_hiaa and affected_region and affected_roi_coords:
        x1, y1, x2, y2 = affected_roi_coords
        cv2.rectangle(result, (x1, y1), (x2, y2), (0, 0, 255), 4)
        region_text = f"{affected_region.upper()} Profile Hiaa (D={D:.3f}, Thresh={dynamic_threshold}{threshold_source}) - {resolution_info}"
        cv2.putText(result, region_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    else:
        status_text = f"No Hiaa (D={D:.3f}, Thresh={dynamic_threshold}{threshold_source}) - {resolution_info}"
        cv2.putText(result, status_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    
    # Apply a mask to the affected area (if have)
    if has_hiaa and affected_region and affected_roi_coords:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
        x1, y1, x2, y2 = affected_roi_coords
        mask[y1:y2, x1:x2] = 255
    else:
        mask = np.zeros(img.shape[:2], dtype=np.uint8)
    
    return result, mask, D, has_hiaa, affected_region, affected_roi_coords, avg_top, avg_bottom, avg_normal, min_top, min_bottom, dynamic_threshold


def check_for_hiaa_in_folder(hiaa_checker_thread, folder_path, file_names_in_group, pattern, 
                             mask_images_dir, mark_hiaa_dir, crop_hiaa_dir):
    """
    Check for hiaa in the folder - FIX ERRORS IMMEDIATELY UPON DETECTION
    """
    base_folder_name = os.path.basename(folder_path)
    hiaa_files = []  # List to track which files have hiaa
    hiaa_results = []  # Store results for files with hiaa
    profile_data_list = []  # Store profile data for CSV export
    
    for file_name in file_names_in_group:
        file_path = os.path.join(folder_path, file_name)

        # Use the detect_hiaa_by_profile function (parameters fully from settings.csv)
        try:
            result, mask, D, has_hiaa, affected_region, affected_roi_coords, avg_top, avg_bottom, avg_normal, min_top, min_bottom, used_threshold = detect_hiaa_by_profile(
                file_path, file_name=file_name
            )
        except Exception as e:
            hiaa_checker_thread.update_log.emit(f"Error processing {file_name}: {str(e)}")
            continue

        # Extract resolution information from the image
        img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
        if img is not None:
            img_height, img_width = img.shape[:2]
            resolution = f"{img_width}x{img_height}"
        else:
            resolution = "Unknown"

        # Identify the threshold source.
        threshold_source = "Threshold 1"
        if file_name:
            _, group_key = _extract_hiaa_pattern_and_group_key(file_name, img_width, img_height)
            if group_key and group_key.endswith("_col2"):
                threshold_source = "Threshold 2"

        # Save profile information for CSV
        profile_data_list.append({
            "Folder": base_folder_name,
            "File Name": file_name,
            "Pattern": pattern if pattern else "Unknown",
            "Resolution": resolution,
            "D Value": D,
            "Top Avg": avg_top,
            "Bottom Avg": avg_bottom,
            "Normal Avg": avg_normal,
            "Top Min": min_top,
            "Bottom Min": min_bottom,
            "Threshold Used": used_threshold,
            "Threshold Source": threshold_source,
            "Has Hiaa": "Yes" if has_hiaa else "No",
            "Affected Region": affected_region if has_hiaa else "None",
            "Status": "Hiaa Found" if has_hiaa else "OK"
        })

        # Save image mask for file with hiaa
        if has_hiaa:
            mask_img_path = os.path.join(mask_images_dir, f"{base_folder_name}_{file_name.replace('.tif', '_mask.png')}")
            cv2.imwrite(mask_img_path, mask)
        
        # If there is a hiaa, save the information
        if has_hiaa:
            hiaa_files.append(file_name)
            
            # Save original image
            original_img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
            if original_img is not None:
                original_img_norm = cv2.normalize(original_img, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
                if len(original_img_norm.shape) == 3:
                    original_img_norm = cv2.cvtColor(original_img_norm, cv2.COLOR_BGR2GRAY)
            else:
                original_img_norm = np.zeros((100, 100), dtype=np.uint8)  # Fallback
            
            # Define cropping area - TAKEN FROM ROI COORDS (adjusted for resolution)
            if has_hiaa and affected_roi_coords:
                crop_coords = affected_roi_coords
            elif affected_region == "top":
                # Default for 2868x1320
                crop_coords = (20, 508, 50, 948)
            else:  # bottom
                crop_coords = (142, 508, 172, 948)
            
            hiaa_results.append({
                "file_name": file_name,
                "original_img": original_img_norm,
                "result_img": result,
                "D_value": D,
                "affected_region": affected_region,
                "crop_coords": crop_coords,
                "used_threshold": used_threshold,
                "threshold_source": threshold_source,
                "profile_data": profile_data_list[-1]  # Reference to the last added profile data
            })
    
    # If at least one file is corrupted (hiaa)
    if hiaa_results:
        # Create a result image with all the files that are missing
        # Use the first image as the base
        base_result = hiaa_results[0]["result_img"]
        
        # Save result image
        aggregated_result_img_path = os.path.join(mark_hiaa_dir, f"{base_folder_name}_{pattern}_hiaa_result.png")
        cv2.imwrite(aggregated_result_img_path, base_result)
        
        # Create cropped images for each file that is affected by hiaa
        individual_cropped_image_paths = []
        for idx, hiaa_info in enumerate(hiaa_results):
            crop_coords = hiaa_info["crop_coords"]
            original_img = hiaa_info["original_img"]
            
            x1, y1, x2, y2 = crop_coords
            # Add padding for cropped image
            padding = int(50 * (original_img.shape[0] / 1320.0))  # Adjust padding according to resolution
            crop_x_start = max(0, x1 - padding)
            crop_y_start = max(0, y1 - padding)
            crop_x_end = min(original_img.shape[1], x2 + padding)
            crop_y_end = min(original_img.shape[0], y2 + padding)
            
            cropped_img = original_img[crop_y_start:crop_y_end, crop_x_start:crop_x_end]
            
            # Create a cropped filename with threshold information
            cropped_filename = f"{base_folder_name}_{pattern}_{hiaa_info['affected_region']}_D{hiaa_info['D_value']:.3f}_Thresh{hiaa_info['used_threshold']}_{hiaa_info['threshold_source']}_{idx+1}_cropped.png"
            individual_cropped_img_path = os.path.join(crop_hiaa_dir, cropped_filename)
            cv2.imwrite(individual_cropped_img_path, cropped_img)
            individual_cropped_image_paths.append(individual_cropped_img_path)
        
        hiaa_checker_thread.update_log.emit(f"Found hiaa in {len(hiaa_files)} files for pattern {pattern} in folder {base_folder_name}")
        
        # Return report entries
        report_entries = []
        for cropped_path in individual_cropped_image_paths:
            report_entries.append({
                "result_img_path": aggregated_result_img_path,
                "cropped_img_path": cropped_path,
            })
        
        return True, report_entries, profile_data_list
    else:
        # No files are corrupted hiaa
        return False, None, profile_data_list


def generate_excel_report(hiaa_checker_thread, output_dir, reports, all_profile_data):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Hiaa Report"
    # Prepare Summary workbook and sheet
    # Use summary_output_folder if provided, otherwise use parent of output_dir
    output_base = hiaa_checker_thread.summary_output_folder if hasattr(hiaa_checker_thread, 'summary_output_folder') and hiaa_checker_thread.summary_output_folder else os.path.dirname(output_dir)
    summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
    if os.path.exists(summary_path):
        summary_wb = _load_wb(summary_path)
    else:
        summary_wb = Workbook()
        summary_wb.active.title = "Summary"
    if "Hiaa Report" in summary_wb.sheetnames:
        summary_ws = summary_wb["Hiaa Report"]
        # Clear old content by removing and recreating
        summary_wb.remove(summary_ws)
        summary_ws = summary_wb.create_sheet("Hiaa Report")
    else:
        summary_ws = summary_wb.create_sheet("Hiaa Report")

    # Determine the maximum number of cropped images to create dynamic column headers
    max_cropped_images = 0
    for report_entry in reports:
        if "Cropped_Images" in report_entry and report_entry["Cropped_Images"] is not None:
            max_cropped_images = max(max_cropped_images, len(report_entry["Cropped_Images"]))

    # Add headers
    headers = ["Folder", "PTN", "Status", "Original Image with Mark"]
    for i in range(max_cropped_images):
        headers.append(f"Cropped Image {i+1}")
    sheet.append(headers)
    summary_ws.append(headers)

    header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
    header_font = Font(bold=True)
    border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

    for col in range(1, len(headers) + 1):
        cell = sheet.cell(row=1, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border_style
        scell = summary_ws.cell(row=1, column=col)
        scell.fill = header_fill
        scell.font = header_font
        scell.alignment = Alignment(horizontal="center", vertical="center")
        scell.border = border_style

    # Set fixed column widths
    sheet.column_dimensions['A'].width = 25  # Folder
    sheet.column_dimensions['B'].width = 20  # PTN
    sheet.column_dimensions['C'].width = 20  # Status
    sheet.column_dimensions['D'].width = 45  # Original Image with Mark
    summary_ws.column_dimensions['A'].width = 25
    summary_ws.column_dimensions['B'].width = 20
    summary_ws.column_dimensions['C'].width = 20
    summary_ws.column_dimensions['D'].width = 45

    # Scale factor for images when embedding into Excel
    scale_factor = 0.25 

    # Alternating background colors for rows with the same folder name
    colors = ["D9EAD3", "C9DAF8"]
    current_color_index = 0
    prev_folder = None

    def calc_status_height(text):
        clean_text = (text or "").strip()
        if not clean_text:
            return 20
        approx_chars_per_line = 28
        lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
        return lines * 18 + 4

    def adjust_status_cells(main_row, summary_row, status_text):
        desired_height = calc_status_height(status_text)
        for target_ws, row in ((sheet, main_row), (summary_ws, summary_row)):
            cell = target_ws.cell(row=row, column=3)
            cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
            current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
            if desired_height > current_height:
                target_ws.row_dimensions[row].height = desired_height

    # Separate reports into two groups: with errors and without errors
    # Display folders with errors first (on top), then folders without errors
    reports_with_errors = []
    reports_without_errors = []
    
    for report_entry in reports:
        status = report_entry.get("Status", "")
        if status == "Hiaa Found":
            reports_with_errors.append(report_entry)
        else:
            reports_without_errors.append(report_entry)
    
    # Combine: errors first, then no errors
    sorted_reports = reports_with_errors + reports_without_errors
    
    for row_idx, report_entry in enumerate(sorted_reports, start=2):
        folder = report_entry.get("Folder", "-")
        ptn = report_entry.get("Pattern", "-")
        status = report_entry.get("Status", "Hiaa Found")
        result_img_path = report_entry.get("Result_Image")
        cropped_images_paths = report_entry.get("Cropped_Images")

        if folder != prev_folder:
            current_color_index = (current_color_index + 1) % 2
            prev_folder = folder
        row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

        row_data = [folder, ptn, status]
        sheet.append(row_data)
        current_excel_row = sheet.max_row
        summary_ws.append(row_data)
        current_summary_row = summary_ws.max_row

        for col in range(1, len(row_data) + 1):
            cell = sheet.cell(row=current_excel_row, column=col)
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.fill = row_fill
            cell.border = border_style
            scell = summary_ws.cell(row=current_summary_row, column=col)
            scell.alignment = Alignment(horizontal="center", vertical="center")
            scell.fill = row_fill
            scell.border = border_style

        adjust_status_cells(current_excel_row, current_summary_row, status)

        # Insert aggregated result image into column D
        if result_img_path and os.path.exists(result_img_path):
            with Image.open(result_img_path) as img_result_pil:
                w, h = img_result_pil.size
            scaled_w = int(w * hiaa_checker_thread.IMAGE_SCALE_FACTOR)
            scaled_h = int(h * hiaa_checker_thread.IMAGE_SCALE_FACTOR)

            img_result = ExcelImage(result_img_path)
            img_result.width = scaled_w
            img_result.height = scaled_h
            sheet.add_image(img_result, f'D{current_excel_row}')
            img_result2 = ExcelImage(result_img_path)
            img_result2.width = scaled_w
            img_result2.height = scaled_h
            summary_ws.add_image(img_result2, f'D{current_summary_row}')

            current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
            new_row_height = int(scaled_h * 0.75) + 2
            sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
            s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
            s_new_row_height = int(scaled_h * 0.75) + 2
            summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)
            
            current_col_width = sheet.column_dimensions['D'].width if sheet.column_dimensions['D'].width is not None else 0
            new_col_width = int(scaled_w / 7) + 2
            sheet.column_dimensions['D'].width = max(current_col_width, new_col_width)
            s_current_col_width = summary_ws.column_dimensions['D'].width if summary_ws.column_dimensions['D'].width is not None else 0
            s_new_col_width = int(scaled_w / 7) + 2
            summary_ws.column_dimensions['D'].width = max(s_current_col_width, s_new_col_width)

        # Insert individual cropped images into dynamic columns starting from column E
        if cropped_images_paths:
            for i, cropped_path in enumerate(cropped_images_paths):
                current_col_idx = 4 + i
                current_col_letter = get_column_letter(current_col_idx + 1)

                if cropped_path and os.path.exists(cropped_path):
                    with Image.open(cropped_path) as img_cropped_pil:
                        crop_width, crop_height = img_cropped_pil.size
                    
                    img_cropped = ExcelImage(cropped_path)
                    max_crop_size = 200
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    img_cropped.width = int(crop_width * crop_ratio)
                    img_cropped.height = int(crop_height * crop_ratio)
                    
                    sheet.add_image(img_cropped, f'{current_col_letter}{current_excel_row}')
                    img_cropped2 = ExcelImage(cropped_path)
                    img_cropped2.width = int(crop_width * crop_ratio)
                    img_cropped2.height = int(crop_height * crop_ratio)
                    summary_ws.add_image(img_cropped2, f'{current_col_letter}{current_summary_row}')

                    current_row_height = sheet.row_dimensions[current_excel_row].height if sheet.row_dimensions[current_excel_row].height is not None else 0
                    new_row_height = int(img_cropped.height * 0.75) + 2
                    sheet.row_dimensions[current_excel_row].height = max(current_row_height, new_row_height)
                    s_current_row_height = summary_ws.row_dimensions[current_summary_row].height if summary_ws.row_dimensions[current_summary_row].height is not None else 0
                    s_new_row_height = int(img_cropped.height * 0.75) + 2
                    summary_ws.row_dimensions[current_summary_row].height = max(s_current_row_height, s_new_row_height)

                    current_col_width = sheet.column_dimensions[current_col_letter].width if sheet.column_dimensions[current_col_letter].width is not None else 0
                    new_col_width = int(img_cropped.width / 7) + 2
                    sheet.column_dimensions[current_col_letter].width = max(current_col_width, new_col_width)
                    s_current_col_width = summary_ws.column_dimensions[current_col_letter].width if summary_ws.column_dimensions[current_col_letter].width is not None else 0
                    s_new_col_width = int(img_cropped.width / 7) + 2
                    summary_ws.column_dimensions[current_col_letter].width = max(s_current_col_width, s_new_col_width)

    excel_file_path = os.path.join(output_dir, "Hiaa_Detection_Report.xlsx")
    workbook.save(excel_file_path)
    # Save/commit Summary workbook
    summary_wb.save(summary_path)
    
    # Create a CSV file containing profile details
    if all_profile_data:
        csv_file_path = os.path.join(output_dir, "Hiaa_Profile_Details.csv")
        df = pd.DataFrame(all_profile_data)
        
        # Arrange columns for easier readability - ADD THRESHOLD SOURCE COLUMN
        column_order = [
            "Folder", "File Name", "Pattern", "Resolution", "Status", "Has Hiaa", "Affected Region",
            "D Value", "Threshold Used", "Threshold Source", "Top Avg", "Bottom Avg", "Normal Avg", "Top Min", "Bottom Min"
        ]
        # Only retain the columns present in the DataFrame
        available_columns = [col for col in column_order if col in df.columns]
        df = df[available_columns]
        
        # Sort by Folder and File Name
        df = df.sort_values(by=["Folder", "File Name"])
        
        # Save file CSV
        df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
        hiaa_checker_thread.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
        hiaa_checker_thread.update_log.emit(f"Total records in CSV: {len(df)}")
    
    try:
        hiaa_checker_thread.update_log.emit(f"Summary updated: {summary_path} -> 'Hiaa Report'")
    except Exception:
        pass


# New class for running analysis in the background thread
class HiaaCheckerThread(QThread):
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    ANALYSIS_RESULTS_FOLDER = "Hiaa_Analysis_Results"
    IMAGE_SCALE_FACTOR = 0.18 # Set constant here

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder  # Folder for Analysis_Report.xlsx
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        self.mask_images_dir = os.path.join(self.analysis_output_folder, "mask_images")
        self.mark_hiaa_dir = os.path.join(self.analysis_output_folder, "mark_hiaa")
        self.crop_hiaa_dir = os.path.join(self.analysis_output_folder, "crop_hiaa")
        
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        os.makedirs(self.mask_images_dir, exist_ok=True)
        os.makedirs(self.mark_hiaa_dir, exist_ok=True)
        os.makedirs(self.crop_hiaa_dir, exist_ok=True)
        self.temp_files_to_delete = [] # Initialize list for temporary files
        self.all_profile_data = []  # Store all profile data for CSV export

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) 
                               for fname in os.listdir(folder_path) 
                               if fname.lower().endswith('.tif') and '_ori.tif' not in fname.lower()]

        if initial_image_paths: # If TIFF images are found directly in the folder (excluding _ori.tif)
            self.update_log.emit(f"Found {len(initial_image_paths)} TIFF images directly in {folder_name}.")
            return initial_image_paths

        # If no direct TIFF images, search subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path: # Skip the root folder itself
                continue
            
            # Filter files for .tif and exclude _ori.tif
            filtered_files = [f for f in files if f.lower().endswith('.tif') and '_ori.tif' not in f.lower()]
            
            if filtered_files: # If any relevant TIFF files found in subfolder
                parent_subfolder_name = os.path.basename(root)
                self.update_log.emit(f"  Found {len(filtered_files)} TIFF images in subfolder: {parent_subfolder_name}")

                for file in filtered_files:
                    original_path = os.path.join(root, file)
                    
                    # Create new name: Parent_Subfolder_Name_Original_File_Name.tif
                    new_file_name = f"{parent_subfolder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path) # Add to deletion list
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            grouped_reports = []
            # Exclude analysis results folders when exporting report
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            # Get a list of subfolders in the root folder
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Prepare images for analysis: copy from subfolders if necessary
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)
                
                if not image_paths_for_analysis:
                    self.update_log.emit(f"No relevant TIFF images found in folder: {folder_name} for analysis.")
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid TIFF images",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                # Determine resolution once per folder (assumption: same resolution within a camera folder)
                folder_img_w = None
                folder_img_h = None
                for _p in image_paths_for_analysis:
                    _img = cv2.imread(_p, cv2.IMREAD_UNCHANGED | cv2.IMREAD_ANYDEPTH)
                    if _img is not None:
                        folder_img_h, folder_img_w = _img.shape[:2]
                        break

                grouped_files_by_position = {}
                for img_path in image_paths_for_analysis:
                    file_name = os.path.basename(img_path)
                    if file_name.lower().endswith(".tif"):
                        pattern, group_key = _extract_hiaa_pattern_and_group_key(file_name, folder_img_w, folder_img_h)
                        if pattern and group_key:
                            if group_key not in grouped_files_by_position:
                                grouped_files_by_position[group_key] = []
                            grouped_files_by_position[group_key].append(file_name)

                if not grouped_files_by_position:
                    grouped_reports.append({
                        "Folder": folder_name,
                        "Pattern": "-",
                        "Status": "No valid pattern found (requires Hiaa_PTN_Check or Hiaa_PTN_Check_2 match in settings.csv)",
                        "Result_Image": None,
                        "Cropped_Images": []
                    })
                    continue

                for group_key, file_names_in_group in grouped_files_by_position.items():
                    hiaa_found_in_group, report_entries, profile_data_list = check_for_hiaa_in_folder(
                        self,
                        folder_path, file_names_in_group, group_key,
                        self.mask_images_dir, self.mark_hiaa_dir, self.crop_hiaa_dir,
                    )
                    
                    self.all_profile_data.extend(profile_data_list)
                    if hiaa_found_in_group:
                        cropped_list = [entry["cropped_img_path"] for entry in (report_entries or []) if entry.get("cropped_img_path")]
                        result_image = report_entries[0]["result_img_path"] if report_entries else None
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "Hiaa Found",
                            "Result_Image": result_image,
                            "Cropped_Images": cropped_list
                        })
                    else:
                        grouped_reports.append({
                            "Folder": folder_name,
                            "Pattern": group_key,
                            "Status": "No hiaa detected",
                            "Result_Image": None,
                            "Cropped_Images": []
                        })
            
            # Debug: Display information about profile data
            if self.all_profile_data:
                self.update_log.emit(f"Total profile records collected: {len(self.all_profile_data)}")
                
                # Analyze pattern distribution
                pattern_counts = {}
                threshold_source_counts = {"Threshold 1": 0, "Threshold 2": 0}
                for data in self.all_profile_data:
                    pattern = data.get("Pattern", "Unknown")
                    pattern_counts[pattern] = pattern_counts.get(pattern, 0) + 1
                    
                    threshold_source = data.get("Threshold Source", "Unknown")
                    if threshold_source in threshold_source_counts:
                        threshold_source_counts[threshold_source] += 1
                
                self.update_log.emit("Pattern distribution in profile data:")
                for pattern, count in pattern_counts.items():
                    self.update_log.emit(f"  {pattern}: {count} files")
                
                self.update_log.emit("Threshold source distribution:")
                for source, count in threshold_source_counts.items():
                    self.update_log.emit(f"  {source}: {count} files")
                
                # Analyze step distributions
                step_counts = {}
                for data in self.all_profile_data:
                    file_name = data.get("File Name", "")
                    step_match = re.search(r'step0([1-9])', file_name, re.IGNORECASE)
                    if step_match:
                        step = step_match.group(0)
                        step_counts[step] = step_counts.get(step, 0) + 1
                
                self.update_log.emit("Step distribution in profile data:")
                for step, count in step_counts.items():
                    self.update_log.emit(f"  {step}: {count} files")
            
            if grouped_reports:
                generate_excel_report(self, self.analysis_output_folder, grouped_reports, self.all_profile_data)
                self.update_log.emit("Analysis complete! Excel report and CSV file generated.")
                
                hiaa_folders = list(set(report['Folder'] for report in grouped_reports if report.get("Status") == "Hiaa Found"))
                self.finished.emit(hiaa_folders)
            else:
                # We will still create CSV if profile data is available
                if self.all_profile_data:
                    csv_file_path = os.path.join(self.analysis_output_folder, "Hiaa_Profile_Details.csv")
                    df = pd.DataFrame(self.all_profile_data)
                    
                    # Sort columns
                    column_order = [
                        "Folder", "File Name", "Pattern", "Resolution", "Status", "Has Hiaa", "Affected Region",
                        "D Value", "Threshold Used", "Threshold Source", "Top Avg", "Bottom Avg", "Normal Avg", "Top Min", "Bottom Min"
                    ]
                    # Only retain the columns present in the DataFrame
                    available_columns = [col for col in column_order if col in df.columns]
                    df = df[available_columns]
                    
                    # Sort by Folder and File Name
                    df = df.sort_values(by=["Folder", "File Name"])
                    
                    df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                    self.update_log.emit(f"Profile details CSV saved: {csv_file_path}")
                    self.update_log.emit(f"Total records in CSV: {len(df)}")
                
                self.update_log.emit("Analysis complete! No folders with hiaa, but CSV file generated.")
                self.finished.emit([])

        except Exception as e:
            self.update_log.emit(f"Error: {type(e).__name__} - {str(e)}")
            import traceback
            self.update_log.emit(f"Traceback: {traceback.format_exc()}")
            self.finished.emit([])
        finally:
            # Clean up temporary copied files
            if self.temp_files_to_delete:
                self.update_log.emit("Cleaning up temporary files...")
                for temp_file in self.temp_files_to_delete:
                    if os.path.exists(temp_file):
                        try:
                            os.remove(temp_file)
                            self.update_log.emit(f"Deleted temporary file: {os.path.basename(temp_file)}")
                        except Exception as e:
                            self.update_log.emit(f"Error deleting temporary file {os.path.basename(temp_file)}: {str(e)}")
                self.temp_files_to_delete.clear()