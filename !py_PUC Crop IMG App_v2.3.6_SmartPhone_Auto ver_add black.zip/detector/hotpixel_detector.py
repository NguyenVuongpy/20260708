import os
import sys
import math
import numpy as np
from PIL import Image
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout,QWidget , QPushButton, QLabel, QTextEdit, QFileDialog, QWidget, QProgressBar, QMessageBox, QHBoxLayout, QFrame, QGraphicsDropShadowEffect
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal,QSize
from PyQt6.QtGui import QFont, QPalette, QColor, QIcon
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as ExcelImage
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from scipy import ndimage
import rc.icons
from PyQt6 import QtCore, QtGui, QtWidgets
import shutil
from openpyxl import load_workbook as _load_wb
try:
    import pythoncom
    import win32com.client as win32
except Exception:
    win32 = None
    pythoncom = None

# Global cache for settings.csv
_SETTINGS_DF = None

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def _load_settings_df():
    """Load settings.csv once and cache it."""
    global _SETTINGS_DF
    if _SETTINGS_DF is not None:
        return _SETTINGS_DF
    try:
        csv_path = os.path.join(script_dir, "settings.csv")
        if os.path.exists(csv_path):
            import pandas as pd
            _SETTINGS_DF = pd.read_csv(csv_path)
        else:
            _SETTINGS_DF = None
    except Exception:
        _SETTINGS_DF = None
    return _SETTINGS_DF


def _get_hotpixel_allowed_ptns_by_resolution(resolution_str):
    """
    Get PTN patterns for a specific resolution from settings.csv.
    resolution_str: format "widthxheight" or "width;height"
    Returns set of PTN patterns to check.
    """
    df = _load_settings_df()
    if df is None or "Display_Resolution" not in df.columns or "HotPixel_PTN_Check" not in df.columns:
        return set()
    
    # Convert resolution_str to match format in CSV (using semicolon)
    if 'x' in resolution_str:
        resolution_str = resolution_str.replace('x', ';')
    
    # Find matching row
    matching_row = df[df["Display_Resolution"].astype(str).str.strip() == resolution_str.strip()]
    
    if matching_row.empty:
        return set()
    
    # Get PTN patterns from the matching row
    ptn_str = matching_row.iloc[0]["HotPixel_PTN_Check"]
    if pd.isna(ptn_str):
        return set()
    
    # Split by semicolon and clean up
    ptns = [p.strip() for p in str(ptn_str).split(';') if p.strip()]
    return set(ptns)


def _filename_matches_ptn(filename, ptn_pattern):
    """
    Check if filename contains the PTN pattern as a substring.
    This allows for flexible matching where filenames may have additional characters.
    """
    # Remove file extension for matching
    filename_without_ext = os.path.splitext(filename)[0]
    
    # Check if the PTN pattern appears anywhere in the filename
    return ptn_pattern in filename_without_ext


class HotpixelChecker(QThread):
    # Signals to update progress and log
    update_progress = pyqtSignal(int)
    update_log = pyqtSignal(str)
    finished = pyqtSignal(list)

    # Scale factor for images in Excel
    IMAGE_SCALE_FACTOR = 0.18
    
    # Folder for analysis results
    ANALYSIS_RESULTS_FOLDER = "Hotpixel_Analysis_Results"

    def __init__(self, root_folder, summary_output_folder=None):
        super().__init__()
        self.root_folder = root_folder
        self.summary_output_folder = summary_output_folder
        self.analysis_output_folder = os.path.join(self.root_folder, self.ANALYSIS_RESULTS_FOLDER)
        os.makedirs(self.analysis_output_folder, exist_ok=True)
        self.temp_files_to_delete = []
        self.all_profile_data = []

    def _prepare_folder_for_analysis(self, folder_path, folder_name):
        # Get a list of TIFF files directly in the folder
        initial_image_paths = [os.path.join(folder_path, fname) for fname in os.listdir(folder_path) if fname.endswith('.tif') and '_ori.tif' not in fname]

        if initial_image_paths:
            return initial_image_paths

        # If there are no direct TIFF images, search in subfolders and copy them to the root folder
        self.update_log.emit(f"No TIFF images found directly in {folder_name}. Searching subfolders and copying...")
        copied_image_paths = []
        for root, _, files in os.walk(folder_path):
            if root == folder_path:
                continue

            for file in files:
                if file.endswith('.tif') and '_ori.tif' not in file:
                    original_path = os.path.join(root, file)
                    parent_folder_name = os.path.basename(root)
                    base_folder_name = parent_folder_name.split('_')[0]
                    new_file_name = f"{base_folder_name}_{file}"
                    destination_path = os.path.join(folder_path, new_file_name)
                    
                    shutil.copy2(original_path, destination_path)
                    copied_image_paths.append(destination_path)
                    self.temp_files_to_delete.append(destination_path)
                    self.update_log.emit(f"Copied '{os.path.basename(original_path)}' to '{new_file_name}' in {folder_name} for analysis.")

        return copied_image_paths

    def run(self):
        try:
            results = []
            hotpixel_folders = []
            # Exclude analysis results folders
            excluded_folders = ["Hiaa_Analysis_Results", "Bubble_Analysis_Results", "Hotpixel_Analysis_Results", "Dust_Analysis_Results",
                               "LShape_Analysis_Results", "CCD_Analysis_Results", "Top_Edge_Analysis_Results"]
            folders = [f for f in os.listdir(self.root_folder) 
                      if os.path.isdir(os.path.join(self.root_folder, f)) 
                      and f not in excluded_folders]
            total_folders = len(folders)

            if total_folders == 0:
                self.finished.emit([])
                return

            # Define position tolerance
            POSITION_TOLERANCE = 8

            def are_positions_similar(pos1, pos2):
                return abs(pos1[0] - pos2[0]) <= POSITION_TOLERANCE and abs(pos1[1] - pos2[1]) <= POSITION_TOLERANCE

            for idx, folder_name in enumerate(folders):
                folder_path = os.path.join(self.root_folder, folder_name)
                
                # Prepare images for analysis
                image_paths_for_analysis = self._prepare_folder_for_analysis(folder_path, folder_name)

                if not image_paths_for_analysis:
                    self.update_log.emit(f"No TIFF images found in folder: {folder_name}")
                    results.append({
                        'Folder': folder_name,
                        'PTN': None,
                        'Hotpixel Coordinates': None,
                        'Cropped Image Path': None,
                        'Source Image Path': None,
                        'Hotpixel Intensity': None,
                        'Hotpixel Size': None,
                        'Status': 'No valid TIFF images available for checking'
                    })
                    continue

                self.update_progress.emit(int((idx + 1) / total_folders * 100))
                self.update_log.emit(f"Checking folder: {folder_name}...")

                # Determine resolution and get allowed PTNs from settings.csv
                if image_paths_for_analysis:
                    first_img = Image.open(image_paths_for_analysis[0])
                    img_width, img_height = first_img.size
                    resolution_str = f"{img_width};{img_height}"
                    allowed_ptns = _get_hotpixel_allowed_ptns_by_resolution(resolution_str)
                    self.update_log.emit(f"Image resolution: {img_width}x{img_height}")
                    self.update_log.emit(f"PTNs to check: {len(allowed_ptns)} patterns from settings.csv")
                
                # If no allowed PTNs for this resolution, skip the folder
                if not allowed_ptns:
                    self.update_log.emit(f"No PTN patterns defined for resolution {resolution_str} in settings.csv, skipping folder")
                    results.append({
                        'Folder': folder_name,
                        'PTN': None,
                        'Hotpixel Coordinates': None,
                        'Cropped Image Path': None,
                        'Source Image Path': None,
                        'Hotpixel Intensity': None,
                        'Hotpixel Size': None,
                        'Status': f'No PTN patterns defined for resolution {resolution_str}'
                    })
                    continue
                
                # Group images by which allowed PTN they match
                # Create a mapping from PTN to list of image paths
                image_groups = {ptn: [] for ptn in allowed_ptns}
                
                for img_path in image_paths_for_analysis:
                    img_name = os.path.basename(img_path)
                    img_name_without_ext = os.path.splitext(img_name)[0]
                    
                    # Check which PTN this filename matches
                    matched_ptn = None
                    for ptn in allowed_ptns:
                        if _filename_matches_ptn(img_name, ptn):
                            matched_ptn = ptn
                            break
                    
                    if matched_ptn:
                        image_groups[matched_ptn].append(img_path)
                        self.update_log.emit(f"File {img_name} matched PTN: {matched_ptn}")
                    else:
                        self.update_log.emit(f"File {img_name} does not match any allowed PTN, skipping")
                
                # Remove PTNs with no images
                image_groups = {ptn: paths for ptn, paths in image_groups.items() if paths}
                
                if not image_groups:
                    results.append({
                        'Folder': folder_name,
                        'PTN': None,
                        'Hotpixel Coordinates': None,
                        'Cropped Image Path': None,
                        'Source Image Path': None,
                        'Hotpixel Intensity': None,
                        'Hotpixel Size': None,
                        'Status': 'No images match any PTN from settings.csv'
                    })
                    continue
                
                has_valid_ptn_groups = False
                
                # Check for hotpixels in each PTN group
                for ptn, img_paths_in_group in image_groups.items():
                    if len(img_paths_in_group) < 2:
                        self.update_log.emit(f"PTN {ptn} has only {len(img_paths_in_group)} image(s), need at least 2 for comparison")
                        continue
                    
                    has_valid_ptn_groups = True
                    hotpixel_data = []
                    files_in_group = []  # Track all files in this PTN group
                    
                    for img_path in img_paths_in_group:
                        img = np.array(Image.open(img_path))
                        img_name = os.path.basename(img_path)
                        files_in_group.append(img_name)
                        
                        img_height, img_width = img.shape[:2]
                        resolution = f"{img_width}x{img_height}"
                        
                        max_intensity = np.max(img)
                        mean_intensity = np.mean(img)
                        
                        # Find all pixels with maximum intensity
                        hotpixel_mask = img == max_intensity
                        labeled_mask, num_features = ndimage.label(hotpixel_mask)
                        
                        hotpixel_found = False
                        hotpixel_position = None
                        hotpixel_size = 0
                        
                        for feature_idx in range(1, num_features + 1):
                            feature_positions = np.argwhere(labeled_mask == feature_idx)
                            
                            if len(feature_positions) <= 3:
                                y, x = feature_positions[0]
                                hotpixel_data.append({
                                    'position': (x, y),
                                    'intensity': max_intensity,
                                    'size': len(feature_positions),
                                    'img_path': img_path,
                                    'filename': img_name
                                })
                                hotpixel_found = True
                                hotpixel_position = (x, y)
                                hotpixel_size = len(feature_positions)
                                break
                        
                        # Save profile data for ALL files (will update In_Common later)
                        # In_Common: "OK" for not common, "NG" for common hotpixel
                        self.all_profile_data.append({
                            "Folder": folder_name,
                            "File Name": img_name,
                            "Pattern": ptn,
                            "Resolution": resolution,
                            "Max Intensity": max_intensity,
                            "Mean Intensity": mean_intensity,
                            "Hotpixel Found": "Yes" if hotpixel_found else "No",
                            "Hotpixel Position": str(hotpixel_position) if hotpixel_position else "None",
                            "Hotpixel Size": hotpixel_size if hotpixel_found else 0,
                            "In_Common": "OK",  # Default is OK, will change to NG if part of common hotpixel
                            "Status_Check": "Hotpixel Found" if hotpixel_found else "OK",
                            "Status": "OK"  # Will change to NG if part of common hotpixel
                        })
                    
                    # Check for clusters of similar positions
                    if len(hotpixel_data) >= 3:
                        position_clusters = []
                        data_clusters = []
                        remaining_data = hotpixel_data.copy()
                        
                        while remaining_data:
                            current_data = remaining_data[0]
                            current_pos = current_data['position']
                            
                            similar_indices = [i for i, data in enumerate(remaining_data) 
                                             if are_positions_similar(current_pos, data['position'])]
                            
                            cluster_data = [remaining_data[i] for i in similar_indices]
                            cluster_positions = [data['position'] for data in cluster_data]
                            
                            position_clusters.append(cluster_positions)
                            data_clusters.append(cluster_data)
                            
                            for i in sorted(similar_indices, reverse=True):
                                del remaining_data[i]
                        
                        for cluster_idx, cluster in enumerate(position_clusters):
                            if len(cluster) >= 3:
                                avg_x = int(round(sum(p[0] for p in cluster) / len(cluster)))
                                avg_y = int(round(sum(p[1] for p in cluster) / len(cluster)))
                                avg_pos = (avg_x, avg_y)
                                
                                cluster_data = data_clusters[cluster_idx]
                                hotpixel_scores = [data['intensity'] * data['size'] for data in cluster_data]
                                strongest_idx = np.argmax(hotpixel_scores)
                                strongest_data = cluster_data[strongest_idx]
                                
                                # Update In_Common and Status for files in this cluster
                                # Set In_Common to "NG" for files that have common hotpixel
                                files_in_cluster = [data['filename'] for data in cluster_data]
                                for profile in self.all_profile_data:
                                    if (profile["Folder"] == folder_name and 
                                        profile["File Name"] in files_in_cluster and 
                                        profile["Pattern"] == ptn):
                                        profile["In_Common"] = "NG"  # Changed from "Yes" to "NG"
                                        profile["Status"] = "NG"
                                        profile["Status_Check"] = "Hotpixel Found"
                                
                                crop_path = self.save_hotpixel_image(strongest_data['img_path'], avg_pos, folder_name, ptn)
                                results.append({
                                    'Folder': folder_name,
                                    'PTN': ptn,
                                    'Hotpixel Coordinates': avg_pos,
                                    'Original Positions': cluster,
                                    'Cropped Image Path': crop_path,
                                    'Source Image Path': strongest_data['img_path'],
                                    'Source Filename': strongest_data['filename'],
                                    'Hotpixel Intensity': strongest_data['intensity'],
                                    'Hotpixel Size': strongest_data['size'],
                                    'Status': 'Hotpixel Found'
                                })
                                if folder_name not in hotpixel_folders:
                                    hotpixel_folders.append(folder_name)
                                self.update_log.emit(f"Hotpixel found in PTN: {ptn} at {avg_pos} (intensity: {strongest_data['intensity']}, size: {strongest_data['size']}) from file: {strongest_data['filename']}")
                
                # If no hotpixel found but we had valid PTN groups
                if not any(result['Folder'] == folder_name for result in results):
                    if has_valid_ptn_groups:
                        results.append({
                            'Folder': folder_name,
                            'PTN': None,
                            'Hotpixel Coordinates': None,
                            'Cropped Image Path': None,
                            'Source Image Path': None,
                            'Hotpixel Intensity': None,
                            'Hotpixel Size': None,
                            'Status': 'No Hotpixel'
                        })
                    else:
                        results.append({
                            'Folder': folder_name,
                            'PTN': None,
                            'Hotpixel Coordinates': None,
                            'Cropped Image Path': None,
                            'Source Image Path': None,
                            'Hotpixel Intensity': None,
                            'Hotpixel Size': None,
                            'Status': 'No PTN groups with at least 2 images'
                        })

            self.export_to_excel(results)
            self.update_progress.emit(100) 
            self.finished.emit(hotpixel_folders)
        except Exception as e:
            self.update_log.emit(f"Error: {str(e)}")
            self.finished.emit([])

    def save_hotpixel_image(self, img_path, hotpixel_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)

            x, y = hotpixel_pos
            crop_size = 50
            left = max(0, x - crop_size // 2)
            top = max(0, y - crop_size // 2)
            right = min(img_array.shape[1], x + crop_size // 2)
            bottom = min(img_array.shape[0], y + crop_size // 2)

            cropped_img = img.crop((left, top, right, bottom))
            
            if cropped_img.mode in ('I;16', 'I'):
                array = np.array(cropped_img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                cropped_img = Image.fromarray(array, mode='L')

            output_folder = os.path.join(self.analysis_output_folder, "hotpixel_crops")
            os.makedirs(output_folder, exist_ok=True)
            output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_hotpixel_crop.jpg")
            cropped_img.save(output_path, 'JPEG', quality=95)
            return output_path
        except Exception as e:
            self.update_log.emit(f"Error saving cropped image: {str(e)}")
            return None

    def save_marked_image(self, img_path, hotpixel_pos, folder_name, ptn):
        try:
            img = Image.open(img_path)
            img_array = np.array(img)
            
            if img_array.dtype == np.uint16:
                array = np.array(img, dtype=np.float32)
                array -= array.min()
                array /= array.max()
                array *= 255.0
                array = array.astype(np.uint8)
                img = Image.fromarray(array, mode='L')
            
            img_rgb = img.convert('RGB')
            img_array = np.array(img_rgb)
            
            x, y = hotpixel_pos
            size = 30
            color = [255, 0, 0]
            
            for i in range(-size, size + 1):
                for j in range(-size, size + 1):
                    if (abs(i) >= size-3 or abs(j) >= size-3) and \
                       0 <= x + i < img_array.shape[1] and 0 <= y + j < img_array.shape[0]:
                        img_array[y + j, x + i] = color
            
            marked_img = Image.fromarray(img_array)
            
            output_folder = os.path.join(self.analysis_output_folder, "hotpixel_marked")
            os.makedirs(output_folder, exist_ok=True)
            output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_marked.jpg")
            marked_img.save(output_path, 'JPEG', quality=95)
            
            new_width = int(marked_img.width * self.IMAGE_SCALE_FACTOR)
            new_height = int(marked_img.height * self.IMAGE_SCALE_FACTOR)
            scaled_marked_img = marked_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            scaled_output_path = os.path.join(output_folder, f"{folder_name}_{ptn}_marked_scaled.jpg")
            scaled_marked_img.save(scaled_output_path, 'JPEG', quality=95)
            self.temp_files_to_delete.append(scaled_output_path)
            
            return output_path, scaled_output_path, marked_img.size
        except Exception as e:
            self.update_log.emit(f"Error saving marked image: {str(e)}")
            return None, None, None

    def export_to_excel(self, results):
        try:
            wb = Workbook()
            ws = wb.active
            ws.title = "Hotpixel Report"
            
            output_base = self.summary_output_folder if self.summary_output_folder else self.root_folder
            summary_path = os.path.join(output_base, "Analysis_Report.xlsx")
            if os.path.exists(summary_path):
                summary_wb = _load_wb(summary_path)
            else:
                summary_wb = Workbook()
                summary_wb.active.title = "Summary"
            
            if "Hotpixel Report" in summary_wb.sheetnames:
                s_ws = summary_wb["Hotpixel Report"]
                summary_wb.remove(s_ws)
                s_ws = summary_wb.create_sheet("Hotpixel Report")
            else:
                s_ws = summary_wb.create_sheet("Hotpixel Report")

            headers = ["Folder", "PTN", "Hotpixel Coordinates", "Intensity", "Size", "Status", "Original Image with Mark", "Cropped Image"]
            ws.append(headers)
            s_ws.append(headers)

            header_fill = PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid")
            header_font = Font(bold=True)
            border_style = Border(left=Side(style="thin"), right=Side(style="thin"), top=Side(style="thin"), bottom=Side(style="thin"))

            for col in range(1, len(headers) + 1):
                cell = ws.cell(row=1, column=col)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.border = border_style
                scell = s_ws.cell(row=1, column=col)
                scell.fill = header_fill
                scell.font = header_font
                scell.alignment = Alignment(horizontal="center", vertical="center")
                scell.border = border_style

            # Set column widths
            col_widths = [25, 20, 20, 15, 10, 20, 45, 22]
            for i, width in enumerate(col_widths, 1):
                col_letter = get_column_letter(i)
                ws.column_dimensions[col_letter].width = width
                s_ws.column_dimensions[col_letter].width = width

            colors = ["D9EAD3", "C9DAF8"]
            current_color_index = 0
            prev_folder = None

            def calc_status_height(text):
                clean_text = (text or "").strip()
                if not clean_text:
                    return 18
                approx_chars_per_line = 28
                lines = max(1, math.ceil(len(clean_text) / approx_chars_per_line))
                return lines * 18 + 4

            def adjust_status_cells(main_row, summary_row, status_text):
                desired_height = calc_status_height(status_text)
                for target_ws, row in ((ws, main_row), (s_ws, summary_row)):
                    cell = target_ws.cell(row=row, column=6)
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrapText=True)
                    current_height = target_ws.row_dimensions[row].height if target_ws.row_dimensions[row].height is not None else 0
                    if desired_height > current_height:
                        target_ws.row_dimensions[row].height = desired_height

            results_with_errors = [r for r in results if r.get('Status') == 'Hotpixel Found']
            results_without_errors = [r for r in results if r.get('Status') != 'Hotpixel Found']
            sorted_results = results_with_errors + results_without_errors

            for result in sorted_results:
                folder = result.get('Folder', '-')
                ptn = result.get('PTN', '-') or '-'
                coordinates = result.get('Hotpixel Coordinates')
                intensity = result.get('Hotpixel Intensity')
                size = result.get('Hotpixel Size')
                status = result.get('Status', 'Unknown')
                crop_path = result.get('Cropped Image Path')
                source_img_path = result.get('Source Image Path')

                if folder != prev_folder:
                    current_color_index = (current_color_index + 1) % 2
                    prev_folder = folder

                row_fill = PatternFill(start_color=colors[current_color_index], end_color=colors[current_color_index], fill_type="solid")

                row = [
                    folder,
                    ptn,
                    str(coordinates) if coordinates else '-',
                    intensity if intensity is not None else '-',
                    size if size is not None else '-',
                    status
                ]
                ws.append(row)
                row_idx = ws.max_row
                s_ws.append(row)
                s_row_idx = s_ws.max_row

                for col in range(1, len(row) + 1):
                    cell = ws.cell(row=row_idx, column=col)
                    cell.alignment = Alignment(horizontal="center", vertical="center")
                    cell.fill = row_fill
                    cell.border = border_style
                    scell = s_ws.cell(row=s_row_idx, column=col)
                    scell.alignment = Alignment(horizontal="center", vertical="center")
                    scell.fill = row_fill
                    scell.border = border_style

                adjust_status_cells(row_idx, s_row_idx, status)

                if coordinates and status == 'Hotpixel Found' and source_img_path and os.path.exists(source_img_path):
                    original_marked_path, scaled_marked_path, original_size = self.save_marked_image(source_img_path, coordinates, folder, ptn)
                    if scaled_marked_path:
                        with Image.open(scaled_marked_path) as scaled_pil_img:
                            scaled_width, scaled_height = scaled_pil_img.size
                        
                        img = ExcelImage(scaled_marked_path)
                        img.width = scaled_width
                        img.height = scaled_height
                        ws.add_image(img, f'G{row_idx}')
                        
                        img2 = ExcelImage(scaled_marked_path)
                        img2.width = scaled_width
                        img2.height = scaled_height
                        s_ws.add_image(img2, f'G{s_row_idx}')
                        
                        new_row_height = int(scaled_height * 0.75) + 2
                        ws.row_dimensions[row_idx].height = max(ws.row_dimensions[row_idx].height or 0, new_row_height)
                        s_ws.row_dimensions[s_row_idx].height = max(s_ws.row_dimensions[s_row_idx].height or 0, new_row_height)
                        
                        new_col_width = int(scaled_width / 7) + 2
                        ws.column_dimensions['G'].width = max(ws.column_dimensions['G'].width or 0, new_col_width)
                        s_ws.column_dimensions['G'].width = max(s_ws.column_dimensions['G'].width or 0, new_col_width)

                if crop_path and os.path.exists(crop_path):
                    with Image.open(crop_path) as cropped_original_img:
                        crop_width, crop_height = cropped_original_img.size
                    
                    max_crop_size = 140
                    crop_ratio = min(max_crop_size / crop_width, max_crop_size / crop_height)
                    
                    img = ExcelImage(crop_path)
                    img.width = int(crop_width * crop_ratio)
                    img.height = int(crop_height * crop_ratio)
                    ws.add_image(img, f'H{row_idx}')
                    
                    img_s = ExcelImage(crop_path)
                    img_s.width = img.width
                    img_s.height = img.height
                    s_ws.add_image(img_s, f'H{s_row_idx}')
                    
                    new_row_height = int(img.height * 0.75) + 2
                    ws.row_dimensions[row_idx].height = max(ws.row_dimensions[row_idx].height or 0, new_row_height)
                    s_ws.row_dimensions[s_row_idx].height = max(s_ws.row_dimensions[s_row_idx].height or 0, new_row_height)
                    
                    new_col_width = int(img.width / 7) + 2
                    ws.column_dimensions['H'].width = max(ws.column_dimensions['H'].width or 0, new_col_width)
                    s_ws.column_dimensions['H'].width = max(s_ws.column_dimensions['H'].width or 0, new_col_width)

            output_excel_path = os.path.join(self.analysis_output_folder, 'hotpixel_report.xlsx')
            wb.save(output_excel_path)
            summary_wb.save(summary_path)
            
            # Create CSV file with all profile data (including In_Common column with OK/NG values)
            if self.all_profile_data:
                csv_file_path = os.path.join(self.analysis_output_folder, "Hotpixel_Profile_Details.csv")
                df = pd.DataFrame(self.all_profile_data)
                
                # Arrange columns for easier readability
                column_order = [
                    "Folder", "File Name", "Pattern", "Resolution", 
                    "Status_Check", "In_Common", "Status",
                    "Hotpixel Found", "Hotpixel Position", "Hotpixel Size",
                    "Max Intensity", "Mean Intensity"
                ]
                available_columns = [col for col in column_order if col in df.columns]
                df = df[available_columns]
                
                # Sort by Folder, then Status (NG first, then OK), then Status_Check, then File Name
                if 'Status' in df.columns:
                    df['Status_Order'] = df['Status'].map({'NG': 0, 'OK': 1})
                    if 'Status_Check' in df.columns:
                        df['Status_Check_Order'] = df['Status_Check'].map({'Hotpixel Found': 0, 'OK': 1})
                        df = df.sort_values(by=["Folder", "Status_Order", "Status_Check_Order", "File Name"])
                        df = df.drop(['Status_Order', 'Status_Check_Order'], axis=1)
                    else:
                        df = df.sort_values(by=["Folder", "Status_Order", "File Name"])
                        df = df.drop('Status_Order', axis=1)
                else:
                    df = df.sort_values(by=["Folder", "File Name"])
                
                df.to_csv(csv_file_path, index=False, encoding='utf-8-sig')
                self.update_log.emit(f"Profile details CSV saved (all files): {csv_file_path}")
                
                # Print statistics
                total_files = len(df)
                ng_files = len(df[df['In_Common'] == 'NG']) if 'In_Common' in df.columns else 0
                ok_files = total_files - ng_files
                common_hotpixel_files = ng_files
                
                self.update_log.emit(f"CSV Statistics: Total={total_files}, NG={ng_files}, OK={ok_files}, Common Hotpixels={common_hotpixel_files}")
            
            self.update_log.emit(f"Excel report saved at: {output_excel_path}")
            self.update_log.emit(f"Summary updated: {summary_path} -> 'Hotpixel Report'")
            
            for temp_file in self.temp_files_to_delete:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            self.temp_files_to_delete.clear()

        except Exception as e:
            self.update_log.emit(f"Error exporting to Excel: {type(e).__name__} - {str(e)}")